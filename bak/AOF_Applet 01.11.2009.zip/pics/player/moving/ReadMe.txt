Die Bilder sind von Ann-Charlott P�hge. Sie hat mir 2 Bilder gegeben (person_oben + person_rechts).
person_unten bzw. person_links sind (und auch person_vorne) sind etwas von mir abge�nderte Pics, die nur
zur Verdeutlichung der Beweg-Richtung dienen. Ich werd Ann-Charlott noch nach weiter Pics fragen.