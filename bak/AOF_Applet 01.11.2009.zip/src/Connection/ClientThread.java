// Listen Thread

package Connection;

import java.io.*;
import java.net.*;

import MainPackage.ExternalPlayer;
import MainPackage.MainApplet;

public class ClientThread extends Thread {

	boolean DEBUG = true; // Debug f�r Umer :D
	static int BUFFSIZE = 128000;
	int port;

	BufferedInputStream input;

	protected int Handle(String in) {		
		//System.out.println("Handle:" + in);
		
		String data[] = in.split("~");
		
		/*Handle data depending of prefix : */
		if (data[0].equals("Loin")) {
			if (data[1].equals("dne")) {
				MainApplet.map.create();
				MainApplet.applet.setContentPanel(1);
			} else if (data[1].equals("bafo")) {
				if (data[2].equals("un"))
					MainApplet.applet.alert("Wrong username!");
				if (data[2].equals("un"))
					MainApplet.applet.alert("Wrong password!");
			} else if (data[1].equals("nf")) {
				MainApplet.applet.alert("User does not exist!");
			} else if (data[1].equals("miss")) {
				if (data[2].equals("mloin"))
					MainApplet.applet.alert("This user is already logged in!");
				if (data[2].equals("wpw"))
					MainApplet.applet.alert("Wrong password!");	
				if (data[2].equals("ipmloin")) {
					MainApplet.applet.alert("To many connections fomr this ip");
					System.exit(0);
				}
			}
		}
		
		if (data[0].equals("upd")) {
			if (data[2].equals("on")) {
				MainApplet.addInfo(data[1] + " is now online.");
				ExternalPlayer.createNew(data[1], data[2], data[3]);
			} else if (data[2].equals("ofl")) {
				MainApplet.addInfo(data[1] + " is now offline.");
			} else {
				if(MainApplet.actPlayer.getName().equals("username"))
					MainApplet.actPlayer.setName(data[1]);								
				
				if (data[1].equals(MainApplet.actPlayer.getName())) {
					//System.out.println("Update : name = "+data[1]);
					//System.out.println("Update : x    = "+data[2]);
					//System.out.println("Update : y    = "+data[3]);
					//System.out.println("Update : mapLV= "+data[4]);
			
					MainApplet.actPlayer.setData(data[1], data[2], data[3], data[4]);
				} else {
					MainApplet.addInfo(data[1] + " just got updated.");
				}
			}
		}	
		
		if (data[0].equals("mss")) {
			if (data[1].equals("miss")) {
				System.exit(0);//if the doesn't have a socket
			} else {
				MainApplet.addInfo(data[1] + " : " + data[2]);//otherwise just show the recieved message
			}
		}
		if (data[0].equals("gmss")) {
			if (data[1].equals("miss")) {
				System.exit(0);//if the doesn't have a socket
			} else {
				MainApplet.addBlueInfo(data[1] + " : " + data[2]);//otherwise just show the recieved message
			}
		}
		
		
		if (data[0].equals("mve")) {	
			System.out.println("ClientThread.handel :: mve - data[1] = "+data[1]);
			if (data[1].equals("dne"));
				MainApplet.actPlayer.moveByServer();
			if (data[1].equals("hck"))
				System.exit(0);//kick the speed hacker - muhaha
		}
		
		return 0;
	}

	// bekommt nen string vom socket
	public String RecvString(char terminal) throws IOException {
		char c;
		String out;

		out = new String("");

		while ((c = (char) input.read()) != terminal)
			out = out + String.valueOf(c);
		return out;
	}

	public ClientThread(Socket sock) throws IOException {
		try {
			// sock = new Socket(InetAddress.getByName(address), port);
			input = new BufferedInputStream(sock.getInputStream(), BUFFSIZE);
			// output = new BufferedOutputStream(sock.getOutputStream(),
			// BUFFSIZE);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Listen Thread gestartet");
	}

	public void run() {
		do {
			String in = new String("");
			try {
				in = RecvString('#');
			} catch (IOException e) {
				e.printStackTrace();
			}
			Handle(in);
		} while (true);
	}
}