package EnhancedChat;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;//for test
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.StringTokenizer;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;

public class ChatBox extends JPanel implements Runnable {
	private final boolean DEBUG = false;// hier f�r extra infos :D
	private static final boolean NONETWORKING = true;// falls nur an der Chatbox
														// gearbeitet werden
														// soll
	private ActionInfoPanelScroll output;
	private JTextField input;
	private JPanel inoutpanel;
	private String UserName, UserRoom, SplitString, ServerData, ServerName;
	private int ServerPort;
	private Socket socket;
	private DataInputStream datainputstream;
	private DataOutputStream dataoutputstream;
	private Thread thread;
	private boolean running;
	private StringTokenizer Tokenizer;

	private JPanel btnPanel;
	private RadioPanelManager fontPanelManager;
	private RadioPanel btnPlain, btnBold, btnItalic;
	private final Font PLAIN = new Font("Dialog", Font.PLAIN, 12);
	private final Font BOLD = new Font("Dialog", Font.BOLD, 12);
	private final Font ITALIC = new Font("Dialog", Font.ITALIC, 12);

	private JPanel colPanel;
	private JButton btnBlack, btnBlue, btnRed, btnGreen, btnBrown;

	public ChatBox() {
		// load the images first
		Image[] i = new Image[12];
		i[0] = getImage("RadioPanelTest/HA_Plain.png");
		i[1] = getImage("RadioPanelTest/HN_Plain.png");
		i[2] = getImage("RadioPanelTest/NA_Plain.png");
		i[3] = getImage("RadioPanelTest/NN_Plain.png");
		i[4] = getImage("RadioPanelTest/HA_Bold.png");
		i[5] = getImage("RadioPanelTest/HN_Bold.png");
		i[6] = getImage("RadioPanelTest/NA_Bold.png");
		i[7] = getImage("RadioPanelTest/NN_Bold.png");
		i[8] = getImage("RadioPanelTest/HA_Italic.png");
		i[9] = getImage("RadioPanelTest/HN_Italic.png");
		i[10] = getImage("RadioPanelTest/NA_Italic.png");
		i[11] = getImage("RadioPanelTest/NN_Italic.png");

		
		
		setLayout(new BorderLayout());

		inoutpanel = new JPanel();
		btnPanel = new JPanel();
		btnPanel.setLayout(new GridLayout(1, 3));

		
		
		btnPlain = new RadioPanel(i[3],i[2],i[1],i[0]);
		btnBold = new RadioPanel(i[7],i[6],i[5],i[4]);
		btnItalic = new RadioPanel(i[11],i[10],i[9],i[8]);
		
		btnPlain.setMinimumSize(new Dimension(70,40));
		btnItalic.setMinimumSize(new Dimension(70,40));
		btnPlain.setMinimumSize(new Dimension(70,40));
		
		btnPanel.add(btnPlain);
		btnPanel.add(btnBold);
		btnPanel.add(btnItalic);

		
		
		output = new ActionInfoPanelScroll();
		input = new JTextField();

		inoutpanel.setLayout(new BorderLayout());
		inoutpanel.add(output, "Center");
		inoutpanel.add(input, "South");

		add(btnPanel, "South");
		add(inoutpanel, "Center");

		input.setActionCommand("input");
		input.addActionListener(new actLis());
	}

	// for test
	public Image getImage(String str) {
		return java.awt.Toolkit.getDefaultToolkit().getImage(str);
	}

	public void paint(Graphics g) {
		output.repaint();
		input.repaint();
		btnPlain.repaint();
		btnBold.repaint();
		btnItalic.repaint();
	}

	public void addInfo(String info, Color col, Font font) {
		output.addInfo(info, col, font);
	}

	class actLis implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (!(input.getText().trim().equals(""))) {
				if (NONETWORKING) {
					addInfo(input.getText(), input.getForeground(), input
							.getFont());
					input.setText("");
				} else {
					SendMessage();
				}
			}

		}
	}

	// for test
	public static void main(String[] args) {
		javax.swing.JFrame f = new javax.swing.JFrame();
		f.setSize(350, 300); // 250,150
		f.setLayout(null);

		JPanel p = new JPanel();
		p.setBounds(0, 0, 350, 300);
		p.setBackground(java.awt.Color.CYAN);
		f.add(p);

		ChatBox cb = new ChatBox();
		cb.setBounds(50, 50, 250, 200);
		f.add(cb);
		f.setVisible(true);
		f.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);

		if (!NONETWORKING)
			cb.RegisterClient();
	}

	// networking
	public void RegisterClient() {
		UserName = "Niels";// ja man muss den namen hier �ndern damit ein 2ter
		// client drauf kann :P
		ServerName = "localhost";
		ServerPort = 1436;
		ConnectToServer();
	}

	private void ConnectToServer() {
		/*********** Initialize the Socket *******/
		output.addInfo("Connecting To Server...");

		try {
			socket = new Socket(ServerName, ServerPort);
			dataoutputstream = new DataOutputStream(socket.getOutputStream());
			SendMessageToServer("HELO " + UserName);
			datainputstream = new DataInputStream(socket.getInputStream());

			thread = new Thread(this);
			thread.start();

			running = true;

		} catch (IOException _IoExc) {
			QuitConnection(0);
		}
	}

	public void run() {
		while (thread != null) {
			try {
				ServerData = datainputstream.readLine();
				/********* LIST UserName;UserName; RFC Coding ***********/
				if (ServerData.startsWith("LIST")) {
					Tokenizer = new StringTokenizer(ServerData.substring(5),
							";");
					/******** Update the Information Label *********/

					if (DEBUG) {
						output.addInfo("Niels: these are all Clients");
						while (Tokenizer.hasMoreTokens()) {
							output.addInfo(Tokenizer.nextToken());
						}
						output.addInfo("----------------------------------");
						output
								.addInfo("Umer:Display this stuff only for debug");
						output.addInfo("----------------------------------");
					}

					output.addInfo("Welcome To " + UserRoom);
				}

				/********* Room Rfc ********/
				if (ServerData.startsWith("ROOM")) {
					/********** Loading Room List in to Room Canvas **************/
					Tokenizer = new StringTokenizer(ServerData.substring(5),
							";");
					UserRoom = Tokenizer.nextToken();

					/********** Add User Item into User Canvas *********/
					if (DEBUG) {
						output.addInfo("-------------DEBUG--------------");
						output.addInfo("UserRoom = " + UserRoom);
						output.addInfo("----------------------------------");
						output.addInfo("Niels: these are all Rooms");
						while (Tokenizer.hasMoreTokens()) {
							output.addInfo(Tokenizer.nextToken());
						}
						output.addInfo("----------------------------------");
					}
				}

				/********** ADD RFC *********/
				if (ServerData.startsWith("ADD")) {

					SplitString = ServerData.substring(5);
					output.addInfo(SplitString + " is now online");
				}

				/********* If User Name Alread Exists **********/
				if (ServerData.startsWith("EXIS")) {
					output.addInfo("User Name Already Exists!");
					thread = null;
					QuitConnection(2);
				}

				/******** REMOVE User RFC Coding **********/
				if (ServerData.startsWith("REMO")) {
					SplitString = ServerData.substring(5);

					output.addInfo(SplitString + " is now offline!");

				}

				/******** MESS RFC Coding Starts **********/
				if (ServerData.startsWith("MESS")) {
					/**** Chk whether ignored user *********/
					output.addInfo(ServerData.substring(5));
				}

				/***** KICK RFC Starts ***********/
				if (ServerData.startsWith("KICK")) {
					output.addInfo("You were kicked because of spamming!");
					thread = null;
					QuitConnection(1);
				}

				/***** INKI RFC (Information about kicked off User *********/
				if (ServerData.startsWith("INKI")) {
					SplitString = ServerData.substring(5);
					output.addInfo(SplitString + " has been kicked!");

				}

				/***** Change Room RFC **********/
				if (ServerData.startsWith("CHRO")) {
					UserRoom = ServerData.substring(5);
				}

				/********** Join Room RFC *************/
				if (ServerData.startsWith("JORO")) {
					SplitString = ServerData.substring(5);
					if (DEBUG) {

						output.addInfo("----------------------------------");
						output.addInfo(SplitString);
						output.addInfo("----------------------------------");
					}

					output.addInfo(SplitString + " is now online");
				}

				/*********** Leave Room RFC **********/
				if (ServerData.startsWith("LERO")) {
					SplitString = ServerData.substring(5, ServerData
							.indexOf("~"));
					output.addInfo(SplitString + " has leaves " + UserRoom
							+ " Room and join into "
							+ ServerData.substring(ServerData.indexOf("~") + 1)
							+ " Room");

				}

				/********** Room Count RFC ********/
				if (ServerData.startsWith("ROCO")) {
					SplitString = ServerData.substring(5, ServerData
							.indexOf("~"));
					output
							.addInfo("Total Users in "
									+ SplitString
									+ " : "
									+ ServerData.substring(ServerData
											.indexOf("~") + 1));
				}

				/******* Private Message RFC **********/
				if (ServerData.startsWith("PRIV")) {
					SplitString = ServerData.substring(5, ServerData
							.indexOf(":"));
					output.addInfo("Private: " + ServerData.substring(5));

				}
			} catch (Exception _Exc) {
				output.addInfo("there was an error");
				QuitConnection(2);
			}
		}
	}

	private void QuitConnection(int QuitType) {
		if (socket != null) {
			try {
				if (QuitType == 0)
					SendMessageToServer("QUIT " + UserName + "~" + UserRoom);
				if (QuitType == 1)
					SendMessageToServer("KICK " + UserName + "~" + UserRoom);
				socket.close();
				socket = null;

			} catch (IOException _IoExc) {
			}
		}
		if (thread != null) {
			thread.stop();
			thread = null;
		}
		running = false;
		output.addInfo("ADMIN: CONNECTION TO THE SERVER CLOSED.");
	}

	private void SendMessageToServer(String Message) {
		try {
			dataoutputstream.writeBytes(Message + "\r\n");
		} catch (IOException _IoExc) {
			QuitConnection(0);
		}
	}

	private void SendMessage() {
		/******** Sending a Message To Server *********/
		SendMessageToServer("MESS " + UserRoom + "~" + UserName + ": "
				+ input.getText());
		output.addInfo(UserName + ": " + input.getText());
		input.setText("");
		input.requestFocus();
	}
}
