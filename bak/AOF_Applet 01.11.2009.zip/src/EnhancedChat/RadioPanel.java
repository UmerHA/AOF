package EnhancedChat;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

import MainPackage.ChatBox;

public class RadioPanel extends JPanel {
	private Image[] img = new Image[4];
	/*
	 * 0 : no hover, not active
	 * 1 : hover, not active
	 * 2 : no hover, active
	 * 3 : hover,active
	 */
	private boolean active = false;
	private boolean hover = false;
	private RadioPanelManager manager;
	private byte idInManager;
	private int height = 0;
	private int width = 0;

	// Constructors:
	public RadioPanel(Image notActive, Image active) {		
		img[0] = notActive;
		img[1] = notActive;
		img[2] = active;
		img[3] = active;
		addMouseListener(new mLis());
		setDimension();
	}
	public RadioPanel(Image noHover_notActive, Image noHover_active,
			Image hover_notActive, Image hover_active) {
		img[0] = noHover_notActive;
		img[1] = hover_notActive;
		img[2] = noHover_active;
		img[3] = hover_active;
		addMouseListener(new mLis());	
		setDimension();
	}

	private void setDimension () {
		this.setMinimumSize(new Dimension(width,height));
		this.setPreferredSize(new Dimension(width,height));
	}
	
	public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height) {		
		for (int i=0;i<4;i++) {
			if (this.height<height)
				this.height=height;
			
			if (this.width<width)
				this.width=width;
		}
		return true;
	}
	
	
	public void setManager (RadioPanelManager manager) {
		this.manager = manager;
		idInManager = manager.addPanel(this);
	}
	public void setActive (boolean bool, RadioPanelManager manager) {
		if (!manager.equals(this.manager))
			return;
		
		this.active = bool;
		repaint();
	}
		
	public void paint(Graphics g) {
		Image pic;
		if (active) {
			if (hover) {
				pic = img[3];
			} else {
				pic = img[2];
			}
		} else {
			if (hover) {
				pic = img[1];
			} else {
				pic = img[0];
			}
		}

		g.drawImage(pic, 0, 0, this);
	}
	
	class mLis extends MouseAdapter {
		public void mouseEntered (MouseEvent e) {
			hover = true;
			repaint();
		}
		public void mouseExited (MouseEvent e) {
			hover = false;
			repaint();
		}
		public void mouseClicked (MouseEvent e) {
			try {			
			manager.requestFocus(idInManager);
			} catch (NullPointerException exc) {
				return;
			}
		}
 	}
	
	// for test
	public static void main(String[] args) {
		Image pic1 = java.awt.Toolkit.getDefaultToolkit().getImage(
			"pics/RadioPanelTest/NN_Plain.png");
		Image pic2 = java.awt.Toolkit.getDefaultToolkit().getImage(
			"pics/RadioPanelTest/NA_Plain.png");
		Image pic3 = java.awt.Toolkit.getDefaultToolkit().getImage(
			"pics/RadioPanelTest/HN_Plain.png");
		Image pic4 = java.awt.Toolkit.getDefaultToolkit().getImage(
			"pics/RadioPanelTest/HA_Plain.png");

		javax.swing.JFrame f = new javax.swing.JFrame();
		f.setSize(350, 300); // 250,150
		f.setLayout(null);

		//JPanel p = new JPanel();
		//p.setBounds(0, 0, 350, 300);
		//p.setBackground(java.awt.Color.CYAN);
		//f.add(p);

		RadioPanel cb = new RadioPanel(pic1, pic2, pic3, pic4);
		cb.setBounds(50, 50, 100, 40);
		RadioPanel cb2 = new RadioPanel(pic1, pic2, pic3, pic4);
		cb2.setBounds(50, 100, 100, 40);
		RadioPanel cb3 = new RadioPanel(pic1, pic2, pic3, pic4);
		cb3.setBounds(50, 150, 100, 40);
		
		RadioPanelManager manager = new RadioPanelManager();
		cb.setManager(manager);
		cb2.setManager(manager);
		cb3.setManager(manager);
		
		f.add(cb);
		f.add(cb2);
		f.add(cb3);
		f.setVisible(true);
		f.setDefaultCloseOperation(javax.swing.JFrame.EXIT_ON_CLOSE);
	}
}
