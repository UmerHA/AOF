package EnhancedChat;

public class RadioPanelManager {
	private RadioPanel[] panels = new RadioPanel[50];
	byte activePanel = 0;
	byte panelAmount = 0;
	
	public byte addPanel (RadioPanel panel) {
		panels[panelAmount] = panel;
		panelAmount++;
		return (byte) (panelAmount-1);
	}
	
	public void requestFocus (byte id) {
		for (int i=0;i<panelAmount;i++) 
			panels[i].setActive(false, this);
		
		panels[id].setActive(true, this);
		this.activePanel = id;

	}

	public RadioPanel getActivePanel () {
		return panels[activePanel];
	}
}
