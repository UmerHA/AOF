package MainPackage;

import java.awt.Graphics;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.URL;

import MapBases.*;
import MapFields.*;
import MapObjects.*;
import Monster.*;
import TNPC.*;

/* Map :
 *
 * The main game takes place inside the map (till now...), excluding the fighting.
 * The map draw everything in different "layers" : Bases,MapFields+MapObjects,Monster,Player
 * The map also manages all the monsters and MapObjects
 */

public class Map {

	public static final int mapSize = 150;
	
	private MapBase[] Bases[] = new MapBase[mapSize][mapSize];
	public MapField[] Fields[] = new MapField[mapSize][mapSize];
	
	private int mapX = 0;
	private int mapY = 0;
	private byte mapLV = 0;

	private int maxFieldsX;
	private int maxFieldsY;

	private MapField currentField;

	private NPC[] npcs = new NPC[mapSize*mapSize];
	private int npcNum = 0;
	
	public void create () {
		mapX = (short) MainApplet.actPlayer.mapXofMap;
		mapY = (short) MainApplet.actPlayer.mapYofMap;

		for (short i = 0; i < mapSize; i++) {
			for (short j = 0; j < mapSize; j++) {
				Fields[i][j] = new PlainField(i, j);
			}
		}

		System.out.println("MapPanel.create :: creating Base");
		createBaseFromFile();
		System.out.println("MapPanel.create :: creating Fields");
		createMapFromFile();
		System.out.println("MapPanel.create :: creating NPCs");
		createMonFromFile();
		System.out.println("MapPanel.create :: created all map items");

		
		currentField = Fields[MainApplet.actPlayer.getMapX()][MainApplet.actPlayer
				.getMapY()];
	}

	public void initMaxFields() {
		int w = MainApplet.WIDTH();
		int h = MainApplet.HEIGHT() - 10;

		maxFieldsX = (int) Math.floor(w / 30);
		maxFieldsY = (int) Math.floor(h / 30);

		// System.out.println (maxFieldsX + " " + maxFieldsY);
	}

	private void createBaseFromFile () {
		String[] data = new String[mapSize*mapSize+1];
		int lines = 0;

		try {
			File file = new File(new URL(MainApplet.applet.getCodeBase(),"data/BaseData"
					+ mapLV).toURI());
			
			FileInputStream fileStream = new FileInputStream(file);
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader fromFile = new BufferedReader(new InputStreamReader(
					dataStream));

			String strLine;
			// Read File Line By Line

			while ((strLine = fromFile.readLine()) != null) {
				if (!strLine.equals("")) {
					data[lines] = strLine;
					lines++;
				}
			}

			fromFile.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}
		
		String dat = (String) data[0].subSequence(1, data[0].length()-1);
		//System.out.println(dat);
		for (short i=0;i<mapSize;i++) {
			for (short j=0;j<mapSize;j++) {	
				
				
				if (dat.equals("Grass")) 
					Bases[i][j] = new Grass(i,j);
				if (dat.equals("Road"))
					Bases[i][j] = new Road(i,j);
				if (dat.equals("Underground"))
					Bases[i][j] = new Underground(i,j);
				if (dat.equals("Nothing"))
					Bases[i][j] = new Nothing(i,j);
			}
		}
		

		String[] temp;
		for (short i = 1; i < lines; i++) {
			temp = data[i].split("~");
			
			int x = Integer.parseInt(temp[1]);
			int y = Integer.parseInt(temp[2]);

			if (temp[0].equals("Grass"))
				Fields[x][y] = new Wood(x, y);
			if (temp[0].equals("Road"))
				Fields[x][y] = new Road(x, y);
			if (temp[0].equals("Underground"))
				Bases[x][y] = new Underground(x,y);
			if (temp[0].equals("Nothing"))
				Bases[x][y] = new Nothing(x,y);

			// new Base
		}
	}
	private void createMapFromFile() {
		String[] data = new String[mapSize*mapSize];
		int lines = 0;

		try {
			File file = new File(new URL(MainApplet.applet.getCodeBase(),"data/MapData"
					+ mapLV).toURI());
			
			FileInputStream fileStream = new FileInputStream(file);
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader fromFile = new BufferedReader(new InputStreamReader(
					dataStream));

			String strLine;
			// Read File Line By Line

			while ((strLine = fromFile.readLine()) != null) {
				if (!strLine.equals("")) {
					data[lines] = strLine;
					lines++;
					// System.out.println("|"+ data[lines-1] +"|");
				}
			}

			fromFile.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		String[] temp;
		for (short i = 0; i < lines; i++) {
			temp = data[i].split("~");
			
			//System.out.println("MapPanel.createFieldFromFile :: short i = "+i);
			int x = Integer.parseInt(temp[1]);
			int y = Integer.parseInt(temp[2]);

			// System.out.println(data[i]);
			
			//map base
			if (temp[0].equals("Lava"))
				Fields[x][y] = new Lava(x, y);
			if (temp[0].equals("Water"))
				Fields[x][y] = new Water(x, y);
			if (temp[0].equals("Water1"))
				Fields[x][y] = new Water1(x, y);
			if (temp[0].equals("Water2"))
				Fields[x][y] = new Water2(x, y);
			if (temp[0].equals("Sand"))
				Fields[x][y] = new Sand(x, y);
			if (temp[0].equals("Rock"))
				Fields[x][y] = new Rock(x, y);
			if (temp[0].equals("Wood"))
				Fields[x][y] = new Wood(x, y);
			
			//map object
			if (temp[0].equals("LadderUp"))
				Fields[x][y] = new LadderUp(x, y);
			if (temp[0].equals("LadderDown"))
				Fields[x][y] = new LadderDown(x, y);
			if (temp[0].equals("Tree"))
				Fields[x][y] = new Tree(x, y);
			if (temp[0].equals("TropicalTree"))
				Fields[x][y] = new TropicalTree(x, y);
			
			//special
			if (temp[0].equals("Plain"))
				Fields[x][y] = new PlainField(x, y);
			if (temp[0].equals("SpawnField"))
				Fields[x][y] = new TropicalTree(x, y);
			if (temp[0].equals("LavaHole"))
				Fields[x][y] = new LavaHole(x, y);

			// Fences :
			// 1-Line
			if (temp[0].equals("FenceNorth"))
				Fields[x][y] = new FenceNorth(x, y);
			if (temp[0].equals("FenceSouth"))
				Fields[x][y] = new FenceSouth(x, y);
			if (temp[0].equals("FenceEast"))
				Fields[x][y] = new FenceEast(x, y);
			if (temp[0].equals("FenceWest"))
				Fields[x][y] = new FenceWest(x, y);
			// 2-Line
			if (temp[0].equals("FenceNE"))
				Fields[x][y] = new FenceNE(x, y);
			if (temp[0].equals("FenceNW"))
				Fields[x][y] = new FenceNW(x, y);
			if (temp[0].equals("FenceNS"))
				Fields[x][y] = new FenceNS(x, y);
			if (temp[0].equals("FenceSE"))
				Fields[x][y] = new FenceSE(x, y);
			if (temp[0].equals("FenceSW"))
				Fields[x][y] = new FenceSW(x, y);
			if (temp[0].equals("FenceWE"))
				Fields[x][y] = new FenceWE(x, y);
			// 3-line
			if (temp[0].equals("FenceNSE"))
				Fields[x][y] = new FenceNSE(x, y);
			if (temp[0].equals("FenceNSW"))
				Fields[x][y] = new FenceNSW(x, y);
			if (temp[0].equals("FenceNWE"))
				Fields[x][y] = new FenceNWE(x, y);
			if (temp[0].equals("FenceSWE"))
				Fields[x][y] = new FenceSWE(x, y);

			// new Field
		}
	}
	private void createMonFromFile() {
		String[] data = new String[mapSize*mapSize];
		int lines = 0;

		try {
			File file = new File(new URL(MainApplet.applet.getCodeBase(),"data/MonData"
					+ mapLV).toURI());
			FileInputStream fileStream = new FileInputStream(file);
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader fromFile = new BufferedReader(new InputStreamReader(
					dataStream));

			String strLine;
			// Read File Line By Line

			while ((strLine = fromFile.readLine()) != null) {
				if (!strLine.equals("")) {
					data[lines] = strLine;
					lines++;
					// System.out.println("|"+ data[lines-1] +"|");
				}
			}

			fromFile.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		String[] temp;
		for (short i = 0; i < lines; i++) {
			temp = data[i].split("~");
			int x = Integer.parseInt(temp[1]);
			int y = Integer.parseInt(temp[2]);
			int delay = Integer.parseInt(temp[3]);
			
			// System.out.println(" name: |"+ temp[i]+"|");
			// System.out.println("    x:"+ temp[1]);
			// System.out.println("    y:"+ temp[2]);
			// System.out.println("delay:"+ temp[3]);
			// System.out.println("    j:"+ j);
			// System.out.println("");

			//TNPC
			if (temp[0].equals("Joe"))
				npcs[i] = new Joe(x, y,i);	
			if (temp[0].equals("Edward"))
				npcs[i] = new Edward(x, y,i);
			if (temp[0].equals("Adventurer"))
				npcs[i] = new Adventurer(x,y,i);
			if (temp[0].equals("Farmer"))
				npcs[i] = new Farmer(x,y,i);
			
			//monster
			if (temp[0].equals("Dragon"))
				npcs[i] = new Dragon(x, y,i);
			if (temp[0].equals("Demon"))
				npcs[i] = new Demon(x, y,i);
			if (temp[0].equals("Dude"))
				npcs[i] = new Dude(x, y,i);;
			if (temp[0].equals("Goblin"))
				npcs[i] = new Goblin(x, y,i);
			if (temp[0].equals("Chicken"))
				npcs[i] = new Chicken(x, y,i);
			if (temp[0].equals("kA"))
				npcs[i] = new kA(x, y,i);
			if (temp[0].equals("MithrilDragon"))
				npcs[i] = new MithrilDragon(x, y,i);
			if (temp[0].equals("Dog"))
				npcs[i] = new Dog(x, y,i);
			if (temp[0].equals("Phoenix"))
				npcs[i] = new Phoenix(x, y,i);
			if (temp[0].equals("BigGoblin"))
				npcs[i] = new BigGoblin(x, y,i);
			if (temp[0].equals("Ankou"))
				npcs[i] = new Ankou(x, y,i);;
			if (temp[0].equals("Big_kA"))
				npcs[i] = new Big_kA(x, y,i);
			if (temp[0].equals("Jad"))
				npcs[i] = new Jad(x,y,i);
			if (temp[0].equals("Sheep"))
				npcs[i] = new Sheep(x,y,i);
			// new NPC

			try {
			npcs[i].setActive(delay);
			} catch (NullPointerException e){
				System.out.println("Map.crMon :: npcs["+i+"] = "+npcs[i]);
				System.out.println("Map.crMon :: delay = "+delay);
			}
			incrNPCNum();
		}
	}
	
	public void setMonsterActivity(boolean state) {
		for (short i = 0; i < npcNum; i++) {
			try {
			npcs[i].setActive(state);
			} catch (NullPointerException npe) {
				System.out.println("Map.setMonsterActivity :: i = "+i+" ; npcNum = "+npcNum);
			}
		}
	}

	public void drawMap(int spaceLeft, int spaceTop, Graphics g) {
		initMaxFields();

		for (short i = 0; i < maxFieldsX + 2; i++) {
			for (short j = 0; j < maxFieldsY + 2; j++) {
				g.drawImage(Bases[mapX + i][mapY + j].getImage(), 30 * (i-1) + spaceLeft, 30 * (j - 1) + spaceTop, MainApplet.applet);
				g.drawImage(Fields[mapX + i][mapY + j].getImage(), 30* (i - 1) + spaceLeft, 30 * (j - 1) + spaceTop,MainApplet.applet);
			}
		}
		
		// <-- For Debugging
		// g.drawLine(60, 60+10, 60, 150+10);
		// g.drawLine(60, 150+10, 150, 150+10);
		// g.drawLine(150, 150+10, 150, 60+10);
		// g.drawLine(150, 60+10, 60, 60+10);
		// -->

		for (short i = 0; i < npcNum; i++) {
			// System.out.println ("i : "+i);
			// System.out.println("map.drawMap : for -> i = "+i);
			// System.out.println("map.drawMap : for -> NPC Num = "+npcNum);

			Image pic = npcs[i].getImage30();
			int x = npcs[i].getPosX();
			int y = npcs[i].getPosY();

			g.drawImage(pic, 30 * (x - 1) + spaceLeft, 30 * (y - 1) + spaceTop,MainApplet.applet);
		}
		ExternalPlayer.paintAll(g);
	}
	
	
	public void repaint () {
		MainApplet.getGamePanel().fieldScreen().repaint();
	}
	

	public void setCurrentField(short x, short y) {
		if (y < 1) {
			MainApplet.actPlayer.move((short) 4);
			MainApplet.addInfo("There's no way I can go there ...");
			return;
		}
		if (x < 1) {
			MainApplet.actPlayer.move((short) 3);
			MainApplet.addInfo("There's no way I can go there ...");
			return;
		}

		currentField.exited();
		currentField = Fields[x][y];
		currentField.entered();

		//MainProg.GameWin.setTitle("Current Position : " + x + " | " + y);
	}

	public void changeMapCoords (int newX, int newY) {		
		int difX = mapX - newX;
		int difY = mapY - newY;
		
		mapX = newX;
		mapY = newY;
		
		for (int i=0;i<npcNum;i++) {
			npcs[i].posX += difX;
			npcs[i].posY += difY;
		}
		repaint();
	}



	public int getMapX() {
		return mapX;
	}
	public int getMapY() {
		return mapY;
	}

	public void incrMapLV() {
		mapLV++;
	}
	public void decrMapLV() {
		mapLV--;
	}
	public int getMapLV() {
		return (int) mapLV;
	}

	public String getNameOfField(int x, int y) {
		return Fields[x][y].getName();
	}

	public void incrNPCNum() {
		npcNum++;
	}

	public static short checkMove(int x, int y, int dir) {
		int tempMapX = x;
		int tempMapY = y;
		int tempDir = 0;
		switch (dir) {
		case 1:
			tempMapX -= 1;
			tempDir = 3;
			break; // left
		case 2:
			tempMapY -= 1;
			tempDir = 4;
			break; // up
		case 3:
			tempMapX += 1;
			tempDir = 1;
			break; // right
		case 4:
			tempMapY += 1;
			tempDir = 2;
			break; // down
		default:
			return 0;
		}

		if (tempMapX <= 0) {
			return -1;
		}
		if (tempMapX >= 500) {
			return -1;
		}
		if (tempMapY <= 0) {
			return -1;
		}
		if (tempMapY >= 500) {
			return -1;
		}	
		
		if (!MainApplet.map.Fields[x][y].checkAccessible(dir)) {
			//System.out.println("Map.checkMove :: start field is not leavable");
			return 0;
		}

		if (!MainApplet.map.Fields[tempMapX][tempMapY].checkAccessible(tempDir)) {
			//System.out.println("Map.checkMove :: goal field is not accessable");
			return 0;
		}
		return 1;
	}

	public String getNameOfOwner(int x, int y) {
		int id_of_owner = Fields[x][y].getOwnerID();
		if (id_of_owner == -1)
			return "";

		return npcs[id_of_owner].getName();
	}

	public NPC getOwner(int x, int y) {
		int id_of_owner = Fields[x][y].getOwnerID();
		if (id_of_owner > -1) {
			return npcs[id_of_owner];
		} else {
			return null;
		}
	}
	
	public void changeLV (byte k) {
		this.mapLV += k;
		recreateMap();
		System.out.println("Map LV changed to : "+mapLV);
	}
	
	public void recreateMap () {
		// clear arrays :
		for (short i = 0; i < mapSize; i++) {
			for (short j = 0; j < mapSize; j++) {
				Fields[i][j] = new PlainField(i, j);
			}
		}
		for (int i=0;i<100;i++) {
			npcs[i] = null;
		}
		npcNum = 0;
		
		// store data of the new map lv :
		createBaseFromFile();
		createMapFromFile();
		createMonFromFile();
		repaint();
	}

	public void setLV(byte k) {		
		this.mapLV = k;
		recreateMap();
		System.out.println("Map LV changed to : "+mapLV);	
	}

}
