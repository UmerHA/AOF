package MainPackage;

import java.awt.Image;
import java.awt.Toolkit;

public class NPC extends myObject {
	protected Image largeImage;
	protected Image Img100;
	protected Image Img30;
	public static Image deadImage = Toolkit.getDefaultToolkit().getImage("pics/monster/small/dead.png");
	protected int walkingRadius;
	protected int sleepingTime;
	
	public int posX;
	public int posY;
	protected int mapX;
	protected int mapY;
	protected int spawnX;
	protected int spawnY;
	protected int delay = 0;
	protected float cow = 0.8F; //chance of walking
	protected String option1; 
	protected String option2 = "Examine";
	
	public boolean inAction = false; // fighting for example
	public boolean active = false;
	
	public int id;
	
	public short dir = 0; // dirs : 0=not_moving;1=left;2=up;3=right;4=down
	
	protected aThread moveThread;
	
	public int getMapX () {return this.mapX;}
	public int getMapY () {return this.mapY;}
	public int getPosX () {return this.posX;}
	public int getPosY () {return this.posY;}
	public void setInAction (boolean state) {
		this.inAction = state;
	}
	public boolean isInAction () {
		return this.inAction;
	}
	
	public Image getImage30 () {
		return this.Img30;
	}
	public Image getImage100 () {return this.Img100;}
	
	public String getOption1 () {return this.option1;}
	public String getOption2 () {return this.option2;}	
	

	
	public NPC (int x,int y, int id) {
		this.id = id;
		this.spawnX = x;
		this.spawnY = y;
		this.mapX = x;
		this.mapY = y;
		this.posX = x;
		this.posY = y;
		this.moveThread = new aThread();
		//this.setActive(true);
	}
	public void setRadius (int i) {
		this.walkingRadius = i;
	}
	public void setSpeed (int pause) {
		this.sleepingTime = pause;
	}
	public void setDelay (int delay) {
		this.delay = delay;
	}
	public void setActive (boolean state) {
		if (state) {
			setActive (this.delay);
		} else {
			
		}
	}
 
	public void setActive (int delay) {
			this.delay = delay;
			this.active = true;
			moveThread.start();
	}
	public void tick () {this.move();}
	
	public void move () {
		
		double r = Math.random();
		if (r>this.cow)
			return;	//so sometimes the NPC doesn't move
		
		int tempX;
		int tempY;
		boolean isValid;
		int dir;
		
		do {
			tempX = this.mapX;
			tempY = this.mapY;
			dir = (int) ((Math.random()*4)+1);
			switch (dir) {
				case 1  : tempX--;break;	// left
				case 2  : tempY--;break;	// up
				case 3  : tempX++;break;	// right
				case 4  : tempY++;break;	// down
				default : break;
			}
		
			//System.out.println("temp X="+tempX+"	SPx="+this.spawnX);
			//System.out.println("temp Y="+tempY+" 	SPy="+this.spawnY);
			
			// Niels , lies das ^^ : Jetzt alle falschen M�glichkeiten aussortieren :
			// Falls einer der falschen M�glichkeiten auftriftt, wird isValid = false;
			// Wenn isValid false ist, wird der Move nicht ausgef�hrt, und ein neuer berechnet, der dann wieder gepr�ft wird
			// So geht das dann weiter, bis ein m�glicher Move gefunden worden ist , der wird dann ausgef�hrt
			
			isValid = true;
			if (tempX<this.spawnX-walkingRadius)	// falls der NPC aus seinem Wander-Radius herauswill (funktioniert noch nicht...) <- doch, jetzt schon =)
				isValid = false;
			if (tempX>this.spawnX+walkingRadius)
				isValid = false;
			if (tempY<this.spawnY-walkingRadius)
				isValid = false;
			if (tempY>this.spawnY+walkingRadius)
				isValid = false;
			
			switch (dir) {							// falls der NPC die Grenzen der Map �berschreiten will
				case 1  : if (mapX==1) {isValid=false;};break;		// left
				case 2  : if (mapY==1) {isValid=false;};break;		// up
				case 3  : if (mapX==499) {isValid=false;};break;	// right
				case 4  : if (mapX==499) {isValid=false;};break;	// down
				default : break;
			}	
			
			
			try {
				if (MainApplet.map.Fields[tempX][tempY].isTaken()) { 	// wenn das feld, wo er hingehen will, schon von einem NPC besetzt ist
					isValid = false;
					//System.out.println("NPC says : I dont wanna steal my bro's field.    (my name:"+this.getName()+"|my id:"+this.id+")");
				} 
			} catch (Exception e) {}
			try {
				if (!MainApplet.map.Fields[tempX][tempY].isOpenForNPC()) { 	// wenn das feld, wo er hingehen will, nur f�r player ist (wasser,lava,...)
					isValid = false;
					//System.out.println("NPC says : I'm not allows there ...    (my name:"+this.getName()+"|my id:"+this.id+")");
				}
			} catch (Exception e) {}
				
			if (MainPackage.Map.checkMove(mapX, mapY, dir) != 1)	// wenn Move nicht ausf�hrbar, da ein Feld inaccesible ist
				isValid = false;
					
		} while (!isValid);
		
		// wenns ging :
		
		MainApplet.map.Fields[this.mapX][this.mapY].free(); // altes Feld wieder freigeben ...
		
		switch (dir) {
			case 1  : mapX--;posX--;break;	// left
			case 2  : mapY--;posY--;break;	// up
			case 3  : mapX++;posX++;break;	// right
			case 4  : mapY++;posY++;break;	// down
		default : break;
		}		
		
		MainApplet.map.Fields[this.mapX][this.mapY].take(this.id); // ... und neues einnehmen
		
		//System.out.println(isValid);
		//System.out.println("X = "+this.X);
		//System.out.println("Y = "+this.Y);
		
		try {
			MainApplet.map.repaint();
		} catch (NullPointerException e){
			e.printStackTrace();
			System.out.println(MainApplet.map);
		}
	}
	public void use () {}
	
	
	class aThread extends Thread {
		public void run() {
			try {sleep(delay);} catch (InterruptedException e) {}
			
			while (true) { // Endlos-Schleife
				try {
					sleep(sleepingTime);
		        }
		        catch(InterruptedException e) {
		        }
		        if (!inAction && active) 
		        	tick();
			}
		}	  
	}

}
