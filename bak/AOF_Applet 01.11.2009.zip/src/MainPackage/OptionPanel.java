package MainPackage;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class OptionPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	JButton logOut;
	JLabel[] info = new JLabel[6];
	JButton clear;
	JButton showMap;
	JButton showShop;
	
	public OptionPanel () {
		setLayout(new GridLayout(10,1));
		setMinimumSize(new Dimension(250,450));
		setPreferredSize(new Dimension(250,450));
		
		logOut = new JButton("Log Out");
		info[0] = new JLabel("Hier kommen dann Optionen");
		info[1] = new JLabel("wie wir sie in setting reintuhen");
		info[2] = new JLabel("wollten");
		info[3] = new JLabel("");
		info[4] = new JLabel("");
		info[5] = new JLabel("log out ist jetzt auch gleich da");
		showMap = new JButton("Show Map [debug]");
		showShop = new JButton("Show Shop [debug]");
		clear = new JButton("Clear chat [debug]");
		
		for (int i=0;i<6;i++)
			add(info[i]);
		add(showMap);
		add(showShop);
		add(logOut);
		add(clear);
		
		actLis actlis= new actLis();
		logOut.addActionListener(actlis);
		clear.addActionListener(actlis);
		showMap.addActionListener(actlis);
		showShop.addActionListener(actlis);
		
		logOut.setFocusable(false);
		clear.setFocusable(false);
		showMap.setFocusable(false);
		showShop.setFocusable(false);
	}

	public Component add (Component comp) {
		JPanel temp = new JPanel();
		temp.setLayout(new FlowLayout());
		temp.add(comp);
		super.add(temp);
		return comp;
	}
	
	class actLis implements ActionListener {
		public void actionPerformed (ActionEvent e) {
			if (e.getActionCommand().equalsIgnoreCase("log out")) 
				MainApplet.actPlayer.logOut();
			if (e.getActionCommand().equalsIgnoreCase("clear chat [debug]")) 
				MainApplet.getGamePanel().chatbox().output.discardAllInfo();
			if (e.getActionCommand().equalsIgnoreCase("Show Map [debug]")) 
				MainApplet.getGamePanel().fieldScreen().setShowShop(false);
			if (e.getActionCommand().equalsIgnoreCase("Show Shop [debug]")) 
				MainApplet.getGamePanel().fieldScreen().setShowShop(true);
			
		}
	}
}
