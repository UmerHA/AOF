package MapBases;

/*
 * Just a simple road 
 */

public class Road extends MapBase {
	public Road (int x, int y) {
		super (x,y,"pics/fields/Road.jpg");
	}
}
