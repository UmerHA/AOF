package MapBases;

public class Underground extends MapBase {
	public Underground(int x, int y) {
		super (x,y,"pics/fields/Underground.jpg");
	}

}
