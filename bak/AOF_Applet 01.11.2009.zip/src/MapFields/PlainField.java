package MapFields;


public class PlainField extends MapField {
	public PlainField (int x, int y) {		
		super(x,y, "pics/fields/Plain.png");
	}
}
