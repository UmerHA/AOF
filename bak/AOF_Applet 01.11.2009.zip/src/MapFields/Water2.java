package MapFields;

public class Water2 extends MapField {
	public Water2(int x, int y) {
		super(x, y, "pics/fields/Water2.jpg");
		this.openForNPC = false;
	}
}
