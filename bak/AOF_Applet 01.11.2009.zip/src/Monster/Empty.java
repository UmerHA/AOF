package Monster;

import MainPackage.NPC;

public class Empty extends NPC {

	public Empty (int x,int y, int id) {
		super(x,y,id);
		this.name = "None";
		this.Img30 = java.awt.Toolkit.getDefaultToolkit().getImage("pics/monster/small/dead.png");
	}

}
