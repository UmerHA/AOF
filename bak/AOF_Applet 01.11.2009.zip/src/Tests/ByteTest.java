package Tests;

public class ByteTest {
	
	public static void main (String[] args) {
		long num = 1234545556454545455L;
		System.out.println((long) num);
		System.out.println((int) num);
		System.out.println((short) num);
		System.out.println((byte) num);
		System.out.println((float) num);
		System.out.println((double) num);
	}
}
