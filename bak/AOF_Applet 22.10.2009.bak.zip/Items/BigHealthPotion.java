package Items;

import MainPackage.MainApplet;

public class BigHealthPotion extends Item {

	public BigHealthPotion() {
		super("pics/items/HP2_3.png");
		this.name = "Big Health Potion";
		this.examineText = "3 doses of a health potion.";
		this.option1 = "Drink";
		this.destroyAble = true;
		this.max_uses = 3;
		this.mom_uses = this.max_uses;
		this.weight = 0.7;
	}

	public void use() {
		short mom_hp = MainApplet.actPlayer.getMomHP();
		short max_hp = MainApplet.actPlayer.getMaxHP();
		MainApplet.addInfo("You drink a health potion ...");
		if (mom_hp == max_hp) {
			MainApplet.actPlayer.changeHP((short) 10);
		} else if (mom_hp > max_hp - 10) {
			int diff = max_hp - mom_hp;
			MainApplet.addInfo("You gain " + diff
					+ " HP");
			MainApplet.actPlayer.changeHP((short) diff);
		} else {
			MainApplet.addInfo("You gain 10 HP");
			MainApplet.actPlayer.changeHP((short) 10);
		}
		super.use();
	}
	
	public void decrMomUses () {
		this.mom_uses --;
		
		String tempStr = "";
		
		switch (this.mom_uses) {
			case 3 : tempStr = "HP2_3"; this.weight = 0.7; break;
			case 2 : tempStr = "HP2_2"; this.weight = 0.5; break;
			case 1 : tempStr = "HP2_1"; this.weight = 0.3; break;
		}
		
		tempStr = "pics/items/"+tempStr+".png";
		this.pic = java.awt.Toolkit.getDefaultToolkit().getImage(tempStr);
		
		if (this.mom_uses > 1) {
			MainApplet.addInfo ("You still have "+this.mom_uses+" doses left.");
			this.examineText = this.mom_uses + " doses of a health potion.";
		} else if (this.mom_uses == 1) {
			MainApplet.addInfo ("You still have 1 dose left.");
			this.examineText = "1 dose of a health potion.";
		} else {
			MainApplet.addInfo ("You have used up your potion.");
		}
	}
}
