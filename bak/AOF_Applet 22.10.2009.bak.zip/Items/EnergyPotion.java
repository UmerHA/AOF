package Items;

import MainPackage.MainApplet;

public class EnergyPotion extends Item {
	
	public EnergyPotion () {
		super ("pics/items/EnergyPotion.gif");
		this.name = "Energy Potion";
		this.examineText = "This little potion will help me to be unbelieveable fast for 10 seconds !";
		this.option1 = "Drink";
		this.destroyAble = true;
		this.max_uses = 1;
		this.mom_uses = this.max_uses;
		this.weight = 0.2;
	}
	
	public void use () {
		super.use();
		MainApplet.actPlayer.setPauseBeetweenMove(0, 10000, this);
	}
}
