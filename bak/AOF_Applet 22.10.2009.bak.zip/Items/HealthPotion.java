package Items;

import MainPackage.MainApplet;

public class HealthPotion extends Item {
	
	public HealthPotion () {
		super ("pics/items/HP.gif");
		this.name = "Health Potion";
		this.examineText = "Might help me when I'm in trouble ...";
		this.option1 = "Drink";
		this.destroyAble = true;
		this.max_uses = 1;
		this.mom_uses = this.max_uses;
		this.weight = 0.2;
	}
	
	public void use () {
		super.use();
		short mom_hp = MainApplet.actPlayer.getMomHP();
		short max_hp = MainApplet.actPlayer.getMaxHP();
		MainApplet.addInfo("You drink a health potion ...");
		if ( mom_hp == max_hp) {
			MainApplet.actPlayer.changeHP ((short) 10);
		} else if ( mom_hp > max_hp-15) {
			int diff = max_hp-mom_hp;
			MainApplet.addInfo("You gain "+diff+" HP");
			MainApplet.actPlayer.changeHP ((short) diff);
		} else {
			MainApplet.addInfo("You gain 15 HP");
			MainApplet.actPlayer.changeHP ((short) 15);
		}
	}
}
