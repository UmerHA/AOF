package Items;

import java.awt.Image;

import MainPackage.myObject;

public abstract class Item extends myObject {
	public final static short maxNameLenght = 20;

	public int max_uses = 0;
	public int mom_uses = 0;
	public boolean destroyAble = true;

	public double weight;

	public String option1;

	public Image pic;

	public Image getImage() {
		return this.pic;
	}
	public String getOption1() {
		return this.option1;
	}
	public double getWeight() {
		return this.weight;
	}
	public int getMomUses() {
		return mom_uses;
	}
	public boolean isDestroyAble() {
		return destroyAble;
	}

	public Item(String picSrc) {
		this.pic = MainPackage.MainApplet.applet.getImage(MainPackage.MainApplet.applet.getCodeBase(),picSrc);
	}

	public String getNameFormated() {
		StringBuffer sb = new StringBuffer(name);

		short spacesToUse = (short) (maxNameLenght - name.length());
		for (short i = 0; i < spacesToUse; i++) {
			sb.append(" ");
		}

		return sb.toString();
	}

	public static String getNameFormated(String nameGiven) {
		// not used anymore
		StringBuffer sb = new StringBuffer(nameGiven);

		short spacesToUse = (short) (maxNameLenght - nameGiven.length());
		for (short i = 0; i < spacesToUse; i++) {
			sb.append(" ");
		}

		return sb.toString();
	}

	public static Item getItemByName(String str) {
		if (str.equalsIgnoreCase("Sword"))
			return new Sword();
		if (str.equalsIgnoreCase("Health Potion"))
			return new HealthPotion();
		if (str.equalsIgnoreCase("Big Health Potion"))
			return new BigHealthPotion();
		if (str.equalsIgnoreCase("Energy Potion"))
			return new EnergyPotion();
		if (str.equalsIgnoreCase("Platebody"))
			return new Platebody();
		if (str.equalsIgnoreCase("Platelegs"))
			return new Platelegs();
		if (str.equalsIgnoreCase("Platelegs 2"))
			return new Platelegs2();
		if (str.equalsIgnoreCase("Mage Hat"))
			return new MageHat();
		if (str.equalsIgnoreCase("Strange Potion"))
			return new StrangePotion();
		if (str.equalsIgnoreCase("Fist Of Zen"))
			return new FistOfZen();
		if (str.equalsIgnoreCase("Slayer's Platebody"))
			return new SlayersPlatebody();
		if (str.equalsIgnoreCase("Slayer's Platelegs"))
			return new SlayersPlatelegs();
		if (str.equalsIgnoreCase("Slayer's Scythe"))
			return new SlayersScythe();
		if (str.equalsIgnoreCase("Slayer's Helmet"))
			return new SlayersHelmet();
		if (str.equalsIgnoreCase("Wood Shield"))
			return new WoodShield();
		if (str.equalsIgnoreCase("Slayer's Cape"))
			return new SlayersCape();
		if (str.equalsIgnoreCase("Slayer's Chain"))
			return new SlayersChain();
		if (str.equalsIgnoreCase("Slayer's Gloves"))
			return new SlayersGloves();
		if (str.equalsIgnoreCase("Coconut"))
			return new Coconut();
		if (str.equalsIgnoreCase("Half Coconut"))
			return new HalfCoconut();
		// new Item

		return new Items.Empty();
	}

	public void use() {
		if (destroyAble)
			decrMomUses();
	}

	protected void decrMomUses() {
		mom_uses--;
	}

	// equipable items :
	protected int equipZone = -1; // -1 : not equipable

	public boolean isTwoHanded = false; // only for weapons
	
	protected int atkBonus = 0;
	protected int defBonus = 0;

	public int getAttackBonus() {
		return this.atkBonus;
	}
	public int getDefenceBonus() {
		return this.defBonus;
	}
	public int getEquipZone() {
		return this.equipZone;
	}
}
