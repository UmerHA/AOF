package Items;

public class Platebody extends Item {
	
	public Platebody () {
		super ("pics/items/platebody.png");
		this.name = "Platebody";
		this.examineText = "A platebody made out of steel.";
		this.option1 = "Equip";
		this.destroyAble = false;
		this.equipZone = 4;
		this.defBonus = 10;
		this.weight = 5.8;
	}
}