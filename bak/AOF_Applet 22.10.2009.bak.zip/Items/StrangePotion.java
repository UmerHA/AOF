package Items; 

import MainPackage.MainApplet;

public class StrangePotion extends Item {
	
	public StrangePotion () {
		super ("pics/items/StrangePotion.png");
		this.name = "Strange Potion";
		this.examineText = "I wonder what will happen if I drink that ...";
		this.option1 = "Drink";
		this.destroyAble = true;
		this.max_uses = 1;
		this.mom_uses = this.max_uses;
		this.weight = 0.1;
	}
	
	public void use () {
		super.use();
		MainApplet.addInfo("You drink the strange potion ...");
		MainApplet.actPlayer.changeHP ((short) -20);
	}
}
