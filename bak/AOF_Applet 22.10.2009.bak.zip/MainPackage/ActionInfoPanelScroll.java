package MainPackage;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;

public class ActionInfoPanelScroll extends JPanel {
	private static final long serialVersionUID = 1L;
	
	JPanel center;
	JPanel east;	
	
	private JLabel[] labels = new JLabel[10];	
	private String[] infos = new String[500];
	private Color[] colors = new Color[500];
	
	private short showFrom = 0;
	private short infosSaved = 0;
	
	private JScrollBar aJSBar;
	
	public ActionInfoPanelScroll () {
		for (short i=0; i<500; i++)
			//infos[i] = " " + String.valueOf(i);
			infos[i] = " ";
		
		center = new JPanel ();
		east   = new JPanel ();
				
		//setBackground (Color.WHITE);			// new Color (136,170,203) 
		center.setLayout (new GridLayout (10,1));	
		for (short i=0; i<10; i++) {
			labels[i] = new JLabel (" ");
			center.add(labels[i]);
		}
		
		
		aJSBar = new JScrollBar(JScrollBar.VERTICAL);
		aJSBar.addAdjustmentListener(new adjLis());
		aJSBar.addMouseWheelListener(new mwLis());
		aJSBar.setMaximum(11);
		aJSBar.setEnabled(false);
		
		east.setLayout(new BorderLayout());
		east.add(aJSBar,"Center");
		
		setLayout (new BorderLayout());
		add (center , "Center");
		add (east , "East");
		addMouseWheelListener(new mwLis());
		
	}
	


	public void addInfo(String info) {
		addInformation(info,Color.BLACK);
	}
	public void addRedInfo(String info) {
		addInformation(info,Color.RED);
	}
	public void addBlueInfo(String info) {
		addInformation(info,Color.BLUE);
	}	
	private void addInformation(String info, Color col) {
		infos[infosSaved+9] = info;
		colors[infosSaved+9] = col;
		
		refresh();
		
		showFrom ++;
		infosSaved ++;
		
		if (infosSaved > 10) {
			aJSBar.setEnabled (true);
			aJSBar.setMaximum(infosSaved);
			aJSBar.setValue(aJSBar.getValue()+1);
		}		
	}
	
	private void refresh () {
		for (short i=0; i<10; i++) {
			labels[i].setForeground(colors[showFrom+i]);
			labels[i].setText(infos[showFrom+i]);		
		}
		repaint();
	}
	
	class adjLis implements AdjustmentListener {
		private boolean firstTime = true;
		
		public void adjustmentValueChanged (AdjustmentEvent e) {
			if (firstTime) {
				firstTime = false;
				return;
			}
			//System.out.println ("OP_GB.ActionInfoPanelScroll$adjLis.adjustmentValueChanged : Adjustment changed");
			showFrom = (short) (e.getValue() + 9);
			refresh();
		}
	}
	class mwLis implements MouseWheelListener {
		public void mouseWheelMoved(MouseWheelEvent e) {
			
			if (infosSaved <= 10)
				return;
			
			System.out.println ("Mouse Wheel moved : "+e.getWheelRotation());		
			showFrom += (short) e.getWheelRotation();
			
			if (showFrom < 9)
				showFrom = 9;
			if (showFrom > infosSaved-1)
				showFrom = (short) (infosSaved-1);
			
			aJSBar.setValue(showFrom-9);
			refresh();
		}
	}
}
