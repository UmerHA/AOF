package MainPackage;


import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.StringTokenizer;

import javax.swing.JPanel;
import javax.swing.JTextField;

public class ChatBox extends JPanel implements Runnable {
	private static final long serialVersionUID = 1L;

	boolean DEBUG = false;// hier f�r extra infos :D
	ActionInfoPanelScroll output;
	JTextField input;	
	ChatBox cb;
	String UserName,UserRoom,SplitString,ServerData,ServerName;
	int ServerPort;
	Socket socket;
	DataInputStream datainputstream;
	DataOutputStream dataoutputstream;
	Thread thread;
	boolean running;
	StringTokenizer Tokenizer;
	
	GamePanel panel;
	
	JPanel CVM_Panel;
	private boolean CVM_PanelSize_Set;
	
	
	
	public ChatBox (GamePanel panel) {
		this.panel = panel;
		
		output = new ActionInfoPanelScroll();
		input = new JTextField();
		CVM_Panel = new JPanel();
		
		setLayout(new BorderLayout());
		add(output,"Center");
		add(input,"South");
		
		/* falls auf input geklickt wird, holt es sich automatisch den focus --> kein mLis n�tig
		 * output kann den focus nicht haben --> kein keyLis n�tig
		 */
		output.addMouseListener(new mLis());
		input.addActionListener(new actLis());
		input.addKeyListener(new keyLis());
		
		Dimension d = new Dimension(400,150);
		setMinimumSize(d);
		setPreferredSize(d);
	}
	
	public void setInConversation (boolean bool) {
		if (bool) {
			remove(input);
			add(CVM_Panel,"South");
		} else {
			remove(CVM_Panel);
			add(input,"South");
		}
	}
	
	public void paint(Graphics g) {
		if (!CVM_PanelSize_Set) {
			CVM_Panel.setPreferredSize(input.getSize());
			CVM_PanelSize_Set = true;
		}
		
		output.repaint();
		input.repaint();
		CVM_Panel.repaint();
	}
	public void addInfo (String txt) {
		output.addInfo(txt);
	}
	public void addRedInfo (String txt) {
		output.addRedInfo(txt);
	}
	public void addBlueInfo (String txt) {
		output.addBlueInfo(txt);
	}
	
	class actLis implements ActionListener {
		public void actionPerformed (ActionEvent e) {
			if(!(input.getText().trim().equals(""))) {
				SendMessage();
			}
		}
	}
	class mLis extends MouseAdapter {
		public void mouseClicked (MouseEvent e) {
			input.grabFocus();
		}
	}
	class keyLis extends KeyAdapter {
		public void keyPressed (KeyEvent e) {
			if (e.getKeyCode() == KeyEvent.VK_F1)
				MainApplet.getGamePanel().menuPanel().setActivePanel((byte) 0);
			if (e.getKeyCode() == KeyEvent.VK_F2)
				MainApplet.getGamePanel().menuPanel().setActivePanel((byte) 1);
			if (e.getKeyCode() == KeyEvent.VK_F3)
				MainApplet.getGamePanel().menuPanel().setActivePanel((byte) 2);
			if (e.getKeyCode() == KeyEvent.VK_F4)
				MainApplet.getGamePanel().menuPanel().setActivePanel((byte) 3);
			if (e.getKeyCode() == KeyEvent.VK_F5)
				MainApplet.getGamePanel().menuPanel().setActivePanel((byte) 4);
		}
	}
	
	// Server-Client-Communication -->
	public void RegisterClient(String user) {
		UserName = user;
		//UserName = "Niels";// ja man muss den namen hier �ndern damit ein 2ter client drauf kann :P
		ServerName = "localhost";
		ServerPort = 1436;
		//ConnectToServer();
	}
	
	@SuppressWarnings("unused")
	private void ConnectToServer() {
		/*********** Initialize the Socket *******/
		output.addInfo("Connecting To Server...");
		
		try {
			output.addInfo("creating new socket...");	//test
			socket = new Socket("127.0.0.1", ServerPort);
			output.addInfo("new socket created...");	//test
			dataoutputstream = new DataOutputStream(socket.getOutputStream());
			SendMessageToServer("HELO " + UserName);
			datainputstream = new DataInputStream(socket.getInputStream());
			
			thread = new Thread(this);
			thread.start();
			
			running = true;
			
		} catch (IOException _IoExc) {
			output.addInfo("Connection failed...");
			QuitConnection(0);
		}
	}
	@SuppressWarnings("deprecation")
	public void run()
	{
		while(thread != null)
		{
			try {
					ServerData = datainputstream.readLine();									
					/********* LIST UserName;UserName; RFC Coding***********/
					if(ServerData.startsWith("LIST"))
					{
						Tokenizer = new StringTokenizer(ServerData.substring(5),";");						
						/********Update the Information Label *********/
						
						if (DEBUG)
						{						
						output.addInfo("Niels: these are all Clients");
						while(Tokenizer.hasMoreTokens())
						{							
							output.addInfo(Tokenizer.nextToken());							
						}	
						output.addInfo("----------------------------------");
						output.addInfo("Umer:Display this stuff only for debug");
						output.addInfo("----------------------------------");
						}
															
						output.addInfo("Welcome To "+UserRoom);		
					}
					
					/*********Room Rfc ********/
					if( ServerData.startsWith("ROOM"))
					{
						/********** Loading Room List in to Room Canvas **************/
						Tokenizer = new StringTokenizer(ServerData.substring(5),";");
						UserRoom = Tokenizer.nextToken();
						
						/**********Add User Item into User Canvas *********/	
						if (DEBUG)
						{
						output.addInfo("-------------DEBUG--------------");
						output.addInfo("UserRoom = "+UserRoom);
						output.addInfo("----------------------------------");
						output.addInfo("Niels: these are all Rooms");
						while(Tokenizer.hasMoreTokens())
						{							
							output.addInfo(Tokenizer.nextToken());							
						}
						output.addInfo("----------------------------------");
						}
					}
					
					/********** ADD RFC *********/
					if(ServerData.startsWith("ADD"))
					{
						
						
						SplitString = ServerData.substring(5);						
						output.addInfo(SplitString + " is now online");						
					}
					
					/*********If User Name Alread Exists **********/
					if (ServerData.startsWith("EXIS"))
					{						
						output.addInfo("User Name Already Exists!");								
						thread = null;
						QuitConnection(2);
					}					 
					
					/******** REMOVE User RFC Coding **********/
					if (ServerData.startsWith("REMO"))
					{						
						SplitString = ServerData.substring(5);	

						output.addInfo(SplitString+" is now offline!" );
						
						
						
					}
					
					/******** MESS RFC Coding Starts **********/
					if( ServerData.startsWith("MESS"))
					{
						/**** Chk whether ignored user *********/	
							output.addInfo(ServerData.substring(5));							
					}
					
					/***** KICK RFC Starts ***********/
					if (ServerData.startsWith("KICK"))
					{
						output.addInfo("You were kicked because of spamming!");
						thread = null;
						QuitConnection(1);	
					}
					
					/***** INKI RFC (Information about kicked off User *********/
					if( ServerData.startsWith("INKI"))
					{
						SplitString = ServerData.substring(5);							
						output.addInfo(SplitString+" has been kicked!");
						
					}
					
					/***** Change Room RFC **********/
					if( ServerData.startsWith("CHRO"))
					{
						UserRoom = ServerData.substring(5);	
					}
					
					/********** Join Room RFC *************/
					if( ServerData.startsWith("JORO"))
					{
						SplitString = ServerData.substring(5);
						if (DEBUG)
						{
							
						output.addInfo("----------------------------------");
						output.addInfo(SplitString);
						output.addInfo("----------------------------------");
						}					
											
						output.addInfo(SplitString + " is now online");
					}
					
					/***********Leave Room RFC **********/
					if( ServerData.startsWith("LERO"))
					{
						SplitString = ServerData.substring(5,ServerData.indexOf("~"));
						output.addInfo(SplitString+" has leaves "+UserRoom+" Room and join into "+ServerData.substring(ServerData.indexOf("~")+1)+" Room");													
					
					}
					
					/********** Room Count RFC ********/					
					if( ServerData.startsWith("ROCO"))
					{
						SplitString = ServerData.substring(5,ServerData.indexOf("~"));
						output.addInfo("Total Users in "+SplitString+" : "+ServerData.substring(ServerData.indexOf("~")+1));
					}
					
					
					/******* Private Message RFC **********/
					if( ServerData.startsWith("PRIV"))
					{												
						SplitString = ServerData.substring(5,ServerData.indexOf(":"));
						output.addInfo("Private: "+ServerData.substring(5));
									
														
					}
				}catch(Exception _Exc) { output.addInfo("there was an error");QuitConnection(2); }	
		}	
	}
	
	@SuppressWarnings("deprecation")
	private void QuitConnection(int QuitType)
	{		
		if(socket != null)
		{
			try {
				if (QuitType == 0)
					SendMessageToServer("QUIT "+UserName+"~"+UserRoom);
				if (QuitType == 1)
					SendMessageToServer("KICK "+UserName+"~"+UserRoom);
				socket.close();	
				socket = null;
								
			}catch(IOException _IoExc) { }			
		}
		if(thread != null)
		{
			thread.stop();
			thread = null;
		}		
		running = false;
		output.addInfo("ADMIN: CONNECTION TO THE SERVER CLOSED.");					
	}
	
	private void SendMessageToServer(String Message) {
		try {
			dataoutputstream.writeBytes(Message + "\r\n");
		} catch (IOException _IoExc) {
			QuitConnection(0);
		} catch (NullPointerException e) {
			output.addInfo("You are not connected to the server.");
		}
	}
	
	private void SendMessage()
	{
		/********Sending a Message To Server *********/
		SendMessageToServer("MESS "+UserRoom+"~"+UserName+": "+input.getText());
		output.addInfo(UserName+": "+input.getText());	
		input.setText("");
		input.requestFocus();	
	}
	//<--
}
