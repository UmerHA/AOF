package MainPackage;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

/*
 * Not used anymore. Replaced by ChatBox 
 * 
 */

public class Connector {

	private int Mainport = 3141;
	private int port;
	public Connector connector;
	
	public  int send(int transfer){
		int respond = 12;
		
		return respond;
	}
	
	public void ConnectMainServer() {
		Socket server = null;
		try {
			System.out.println("Connecting Main Server");
			server = new Socket("localhost", this.Mainport);
			InputStream in = server.getInputStream();
			OutputStream out = server.getOutputStream();
			out.write(11211);// register MainServer
			int result = in.read();
			System.out.println("Serverresponse : " + result);
			if (result != 0) {
				this.port = result;
				if (server != null)
					try {
						server.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				server = new Socket("localhost", this.port);
				in = server.getInputStream();
				out = server.getOutputStream();
				out.write(11311);// register Manager
				
				//test
				out.write(12345);
			}
		}

		catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (server != null)
				try {
					server.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}

	}

	public boolean checkLogIn (String username, String password) {
		return true;
	}
	
}
