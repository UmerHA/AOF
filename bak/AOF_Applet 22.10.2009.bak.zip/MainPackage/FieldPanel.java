package MainPackage;

import javax.swing.JPanel;

import Monster.NPC;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

public class FieldPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	
	public FieldPanel () {
		super();
		setBackground (Color.WHITE);
		MainApplet.map = new Map();
		addMouseMotionListener (new MMLis()); 
		addMouseListener (new MLis());
		addKeyListener (new keyLis());
		setFocusable(true);
	}
	
	
	public void paint (Graphics g) {
		//super.paint(g);
		
		MainApplet.map.drawMap (0,0,g);
		MainApplet.actPlayer.paint (g);
		
		/*
		 //* Activating this code block would draw the field grid
		 //* 
		g.setColor (Color.BLACK);
		for (short i=0; i<10; i++) {
			g.drawLine (0,(i+1)*30, getWidth(), (i+1)*30);
		}
		for (short j=0; j<25; j++) {
			g.drawLine ((j+1)*30, 0, (j+1)*30, getHeight());
		}
		*/
	}

	class MMLis extends MouseMotionAdapter {
		public void mouseMoved (MouseEvent e) {
			int x = e.getX();
			int y = e.getY();
			
			int mx = MainApplet.toMapCoord (x);
			int my = MainApplet.toMapCoord (y);
			

			String monster = MainApplet.map.getNameOfOwner(mx, my);
			String field = MainApplet.map.getNameOfField (mx,my);

			String info = (mx + " | " + my + "  ("+ x + " | " + y + ") :  ["+field+"]   "+monster);
			if (!monster.equals("")) {
				NPC temp = MainApplet.map.getOwner(mx, my);
				info += "  : {"+temp.getOption1()+" / "+temp.getOption2()+"}";
			}
			if (MainApplet.map.Fields[mx][my].getName().equalsIgnoreCase("TropicalTree"))
				info += " {Pick a fruit}";
			MainApplet.setFlyingInfo(info);
			
		}
	}
	class MLis extends MouseAdapter {
		public void mouseClicked (MouseEvent e) {
			grabFocus();			

			int x = e.getX();
			int y = e.getY();
			
			int mx = MainApplet.toMapCoord (x);
			int my = MainApplet.toMapCoord (y);
			
			if (MainApplet.map.Fields[mx][my].getName().equalsIgnoreCase("TropicalTree")) {
				int px = MainApplet.actPlayer.getMapX();
				int py = MainApplet.actPlayer.getMapY();
				
				if ((Math.abs(px-mx)<2)&&(Math.abs(py-my)<2)) {
					((MapFields.TropicalTree) MainApplet.map.Fields[mx][my]).use();
				} else {
					MainApplet.addInfo("He's too far away, i can't reach him.");
				}
			}
			
			
			
			Monster.NPC npc = MainApplet.map.getOwner(mx, my);
			if (npc == null)
				return;
			
			if (e.getButton() == MouseEvent.BUTTON1) {
				//System.out.println("FieldPanel$MLis.mouseClicked : Left mouse button clicked");
				int px = MainApplet.actPlayer.getMapX();
				int py = MainApplet.actPlayer.getMapY();
				int nx = npc.getMapX();
				int ny = npc.getMapY();
				
				if ((Math.abs(px-nx)<2)&&(Math.abs(py-ny)<2)) {
					npc.use();
				} else {
					MainApplet.addInfo("He's too far away, i can't reach him.");
				}
				
			} else if (e.getButton() == MouseEvent.BUTTON3) {
				MainApplet.addInfo(npc.getExamineText());
				//System.out.println("FieldPanel$MLis.mouseClicked : Right mouse button clicked");
			} 
			
			

		}
	}
	class keyLis extends KeyAdapter {
		public void keyPressed(KeyEvent e) {
			int x = 0;
			int y = 0;

			switch (e.getKeyCode()) {
			case 37:MainApplet.actPlayer.move((short) 1);break;//left
			case 38:MainApplet.actPlayer.move((short) 2);break;//up
			case 39:MainApplet.actPlayer.move((short) 3);break;//right
			case 40:MainApplet.actPlayer.move((short) 4);break;//down
			
			case 65:x--;break;//a
			case 87:y--;break;//w
			case 68:x++;break;//d
			case 83:y++;break;//s
			}
			if (e.getKeyCode() == KeyEvent.VK_F1)
				MainApplet.getGamePanel().menuPanel().setActivePanel((byte) 0);
			if (e.getKeyCode() == KeyEvent.VK_F2)
				MainApplet.getGamePanel().menuPanel().setActivePanel((byte) 1);
			if (e.getKeyCode() == KeyEvent.VK_F3)
				MainApplet.getGamePanel().menuPanel().setActivePanel((byte) 2);
			if (e.getKeyCode() == KeyEvent.VK_F4)
				MainApplet.getGamePanel().menuPanel().setActivePanel((byte) 3);
			if (e.getKeyCode() == KeyEvent.VK_F5)
				MainApplet.getGamePanel().menuPanel().setActivePanel((byte) 4);

			
			/*
			 * Due to layout changes there's currently no mini map.
			 * 
			panels[11].moveMap(x, y);
			 */
			//System.out.println(e.getKeyCode());
		}
	}
}
