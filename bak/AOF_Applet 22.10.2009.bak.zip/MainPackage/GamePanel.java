package MainPackage;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

public class GamePanel extends JPanel {
	private static final long serialVersionUID = 1L;

	private ChatBox chatbox;
	private JPanel mainScreen;
	private InfoPanel infoScreen;
	private FieldPanel fieldScreen;
	private PanelSwitcher menuPanel;

	private InventoryPanel invScreen;
	private InventoryEquipPanel equipScreen;

	public GamePanel() {
		// create sub-panels -->
		mainScreen = new JPanel();
		menuPanel = new PanelSwitcher();
		invScreen = new InventoryPanel(MainApplet.actPlayer
				.getInventoryManager());
		equipScreen = new InventoryEquipPanel(MainApplet.actPlayer
				.getInventoryManager());

		infoScreen = new InfoPanel();
		fieldScreen = new FieldPanel();
		chatbox = new ChatBox(this);

		// shape and add the sub-panels -->
		setLayout(new BorderLayout());

		mainScreen.setLayout(new BorderLayout());
		mainScreen.add(chatbox, "South");
		mainScreen.add(fieldScreen, "Center");
		
		menuPanel.addPanel(invScreen, "Inventory");
		menuPanel.addPanel(equipScreen, "Equipment");
		menuPanel.addPanel(infoScreen, "Stats");
		
		add(mainScreen, "Center");
		add(menuPanel, "East");

		// repositionComponents();

		// add listeners -->
		addMouseListener(new mLis());
	}

	public FieldPanel fieldScreen() {
		return this.fieldScreen;
	}
	public InventoryPanel invScreen() {
		return this.invScreen;
	}
	public InventoryEquipPanel equipScreen() {
		return this.equipScreen;
	}
	public PanelSwitcher menuPanel() {
		return this.menuPanel;
	}	
	public ChatBox chatbox() {
		return this.chatbox;
	}
	public InfoPanel infoScreen() {
		return this.infoScreen;
	}
	
	public void isNowActive() {
		registerClient();
	}

	public boolean registerClient() {
		try {
			chatbox.RegisterClient(MainApplet.actPlayer.getName());
		} catch (Exception e) {
			System.err.println("Error " + e);
			return false;
		}
		return true;
	}

	class mLis extends MouseAdapter {
		public void mousePressed(MouseEvent e) {
			grabFocus();
		}
	}

	public void repaint (Graphics g) {
		chatbox.repaint();
		mainScreen.repaint();
		infoScreen.repaint();
		fieldScreen.repaint();
		menuPanel.repaint();
	}

	/*
	 * Due to layout changes currently the menu panel does not support drag and drop.
	 * 
	 * //--->for MenuPanel //-> Drag & Drop private void repositionPanel () {
	 * menuPanel.setBounds(invX, invY, MP_WIDTH, MP_HEIGHT); invalidate();
	 * validate(); //System.out.println("GamePanel.repostionPanel"); } public
	 * void changePosition (int x, int y) { invX += x; invY += y;
	 * repositionPanel(); //System.out.println("GamePanel.changePosition"); }
	 * //<- public void setMenuPanelContent (int i) {//System.out.println(
	 * "GamePanel.setMenuPanelVisibility :: setting visibility to "+bool);
	 * boolean isMPVisible; isMPVisible = menuPanel.keyPressed((byte) i);
	 * 
	 * if (isMPVisible) { menuPanel.setBounds(invX, invY, MP_WIDTH, MP_HEIGHT);
	 * } else { menuPanel.setBounds(invX, invY, 0, 0); } invalidate();
	 * validate(); repaint(); } //<---
	 */
}