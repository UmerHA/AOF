package MainPackage;

import javax.swing.JApplet;
import javax.swing.JComponent;
import javax.swing.JOptionPane;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

public class MainApplet extends JApplet {
	private static final long serialVersionUID = 1L;

	// private static Image[] npcPics; // to be used later
	// private static Image[] fieldPics;// to be used later
	private static Image[] pics = new Image[100];
	private static JComponent[] panels = new JComponent[2];
	private static byte activePanel = 0;
	private static final int NUMBER_OF_PICS = 16;
	private static final byte NUMBER_OF_CONTENT_PANELS = 2;
	
	//the map
	public static Map map = new Map();

	// the player
	public static Player actPlayer;
	public static boolean playerValid;
	
	// for non-static access
	public static MainApplet applet;

	// for chat box
	private static String username;
	public static void setUsername(String uname) {
		username = uname;
		System.out.println("Setting usename to " + username);
	}
	public static String getUsername() {
		System.out.println("Getting usename " + username);
		return username;
	}
	public static void addInfo(String info) {
		((GamePanel) panels[1]).chatbox().output.addInfo(info);
	}
	public static void addRedInfo(String info) {
		((GamePanel) panels[1]).chatbox().output.addRedInfo(info);
	}
	public static void addBlueInfo(String info) {
		((GamePanel) panels[1]).chatbox().output.addBlueInfo(info);
	}
	// the conversation manager
	private static ConversationManager CVManager;
	// <--

	// for double buffering
	private static Graphics bufferGraphics;
	private static Image offscreen;
	private static Dimension dim;


   
	
	public void init() {
		XPLVconverter.init();
		loadImages();
		
		applet = this;
		dim = getSize();
		//offscreen = createImage(dim.width, dim.height);
		//bufferGraphics = offscreen.getGraphics();
		actPlayer = new Player("username","password");
		panels[0] = new LI_Panel();
		panels[1] = new GamePanel();

		this.setContentPane(panels[0]);
		repaint();
	}
	public void stop () {
		actPlayer.logOut();
	}

	private void loadImages () {
		/*
		 * These images are not in use anymore, due to layout changes ;
		 * The only uses image is the first one.
		 */
		
		pics[0] = getImage(getCodeBase(), "pics/SUBackPic.png");
		pics[1] = getImage(getCodeBase(), "pics/GUI/1.png");
		pics[2] = getImage(getCodeBase(), "pics/GUI/2.png");
		pics[3] = getImage(getCodeBase(), "pics/GUI/3.png");
		pics[4] = getImage(getCodeBase(), "pics/GUI/4.png");
		pics[5] = getImage(getCodeBase(), "pics/GUI/5.png");
		pics[6] = getImage(getCodeBase(), "pics/GUI/6.png");
		pics[7] = getImage(getCodeBase(), "pics/GUI/7.png");
		pics[8] = getImage(getCodeBase(), "pics/GUI/8.png");
		pics[9] = getImage(getCodeBase(), "pics/GUI/9.png");
		pics[10] = getImage(getCodeBase(), "pics/GUI/0.png");
		pics[11] = getImage(getCodeBase(), "pics/GUI/AOF Logo.png");
		pics[12] = getImage(getCodeBase(), "pics/GUI/miniMap.png");
		pics[13] = getImage(getCodeBase(), "pics/GUI/settings.png");
		pics[14] = getImage(getCodeBase(), "pics/GUI/menu.png");
		pics[15] = getImage(getCodeBase(), "pics/GUI/gameArea.png");
		pics[16] = getImage(getCodeBase(), "pics/GUI/bpak.png");
		//System.out.println("MainApplet :: images loaded");
	}

	public void paint(Graphics g) {
		//System.out.println("MainApplet :: repainting ...");
		/*
		Dimension temp = getSize();
		if ((dim.width != temp.width) || (dim.height != temp.height)) {
			offscreen = createImage(dim.width, dim.height);
			bufferGraphics = offscreen.getGraphics();
			((GamePanel) panels[1]).repositionComponents();
			dim.width = temp.width;
			dim.height = temp.height;
		}
		
		*/
		if (bufferGraphics == null) {
			offscreen = createImage(dim.width, dim.height);
			bufferGraphics = offscreen.getGraphics();
		} 
			
		//bufferGraphics.clearRect(0, 0, dim.width, dim.width);
		panels[activePanel].paint(bufferGraphics);
		
		g.drawImage(offscreen, 0, 0, this);
		// 
	}

	public void update(Graphics g) {
		paint(g);
	}

	public void setContentPanel(int i) {
		if (i < 0)
			return;
		if (i > NUMBER_OF_CONTENT_PANELS)
			return;

		switch (i) {
		case 1:
			((GamePanel) panels[1]).isNowActive();
			((GamePanel) panels[1]).menuPanel().setActivePanel((byte)2);
			break;
		}

		activePanel = (byte) i;
		setContentPane(panels[i]);
		invalidate();
		validate();
	}

	public static void setFlyingInfo (String info) {
		getGamePanel().chatbox().input.setText(info);
	}
	
	/*
	 * Images :
	 * 
	 * 0 : Background image of LogInPanel
	 * 1 - 10 : ActionKeys' Images
	 * 11 : AOF logo 
	 * 12 : miniMap 
	 * 13 : settings 
	 * 14 : menu 
	 * 15 : gameArea 
	 * 16 : background image of the action keys 
	 * 17 : image of inventory (for test)
	 */
	public static Image getImage(int id) {
		if (id < 0)
			return null;
		if (id > NUMBER_OF_PICS)
			return null;

		try {
			return pics[id];
		} catch (IndexOutOfBoundsException e) {
			return null;
		}
	}
	public static File getFile (String directory) {
		URL url = null;
		try {
			url = new URL(MainApplet.applet.getCodeBase(),directory);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		URI uri = null;
		try {
			uri = url.toURI();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		
		return new File(uri);
	}
	
	//get Size
	public static int HEIGHT() {
		return dim.height;
	}
	public static int WIDTH() {
		return dim.width;
	}

	public static GamePanel getGamePanel () {
		return (GamePanel) panels[1];
	}

	public static ConversationManager CVManager() {
		if (CVManager == null)
			CVManager = new ConversationManager();
		return CVManager;
	}
	
	// aiding methods
	public static String parseString(short x) {
		return String.valueOf((int) x);
	}
	public void alert(String message) {
		JOptionPane.showMessageDialog(this, message, "OP GB",
				JOptionPane.PLAIN_MESSAGE);
	}
	public boolean confirm(String question) {
		Object[] options = { "Yes", "No" };

		int n = JOptionPane.showOptionDialog(this, question, "OP GB",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null,
				options, options[0]);

		switch (n) {
		case 0:
			return true;
		case 1:
			return false;
		default:
			return false;
		}
	}
	public int yesnocancel(String question) {
		int result = JOptionPane.showConfirmDialog(this, question, "OP GB",
				JOptionPane.YES_NO_CANCEL_OPTION);
		return result;
	}
	public int yesnocancel(String question, String title) {
		int result = JOptionPane.showConfirmDialog(this, question, title,
				JOptionPane.YES_NO_CANCEL_OPTION);
		return result;
	}
	public static int getRandom(int min, int max) { // get random number from
		// min to max
		int difference = (max - min) + 1;
		int r = (int) (Math.random() * difference);

		return (r + min);
	}
	public static int toMapCoord(int x) {
		return (int) Math.floor(x / 30) + 1;
	}

	public static Image getImage (String picPath) {
		return applet.getImage(applet.getCodeBase(), "pics/"+picPath);
	}
	
}
