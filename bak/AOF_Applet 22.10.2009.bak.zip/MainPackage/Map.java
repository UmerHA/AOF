package MainPackage;

import java.awt.Graphics;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.net.URL;

import MapFields.*;
import Monster.*;

/* Map :
 *
 * The main game takes place inside the map (till now...), excluding the fighting.
 * The map draw everything in different "layers" : Background,MapObjects,Monster,Player
 * The map also manages all the monsters and MapObjects
 */

public class Map {

	public MapField[] Fields[] = new MapField[500][500];
	private int mapX = 0;
	private int mapY = 0;
	private byte mapLV = 0;

	private int maxFieldsX;
	private int maxFieldsY;

	private MapField currentField;

	private NPC[] npcs = new NPC[100];
	private int npcNum = 0;
	
	public void create () {
		mapX = (short) MainApplet.actPlayer.mapXofMap;
		mapY = (short) MainApplet.actPlayer.mapYofMap;

		for (short i = 0; i < 500; i++) {
			for (short j = 0; j < 500; j++) {
				Fields[i][j] = new BasicMapField(i, j);
			}
		}

		createMapFromFile();
		createMonFromFile();

		currentField = Fields[MainApplet.actPlayer.getMapX()][MainApplet.actPlayer
				.getMapY()];
	}

	public void initMaxFields() {
		int w = MainApplet.WIDTH();
		int h = MainApplet.HEIGHT() - 10;

		maxFieldsX = (int) Math.floor(w / 30);
		maxFieldsY = (int) Math.floor(h / 30);

		// System.out.println (maxFieldsX + " " + maxFieldsY);
	}

	private void createMapFromFile() {
		String[] data = new String[300];
		short lines = 0;

		try {
			File file = new File(new URL(MainApplet.applet.getCodeBase(),"data/MapData"
					+ mapLV).toURI());
			
			FileInputStream fileStream = new FileInputStream(file);
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader fromFile = new BufferedReader(new InputStreamReader(
					dataStream));

			String strLine;
			// Read File Line By Line

			while ((strLine = fromFile.readLine()) != null) {
				if (!strLine.equals("")) {
					data[lines] = strLine;
					lines++;
					// System.out.println("|"+ data[lines-1] +"|");
				}
			}

			fromFile.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		for (short i = 0; i < lines; i += 3) {
			int x = Integer.parseInt(data[i + 1]);
			int y = Integer.parseInt(data[i + 2]);

			// System.out.println(data[i]);
			
			//natural objects
			if (data[i].equals("Lava"))
				Fields[x][y] = new Lava(x, y);
			if (data[i].equals("Water"))
				Fields[x][y] = new Water(x, y);
			if (data[i].equals("Water1"))
				Fields[x][y] = new Water1(x, y);
			if (data[i].equals("Water2"))
				Fields[x][y] = new Water2(x, y);
			if (data[i].equals("Sand"))
				Fields[x][y] = new Sand(x, y);
			if (data[i].equals("Rock"))
				Fields[x][y] = new Rock(x, y);
			if (data[i].equals("Wood"))
				Fields[x][y] = new Wood(x, y);
			if (data[i].equals("Tree"))
				Fields[x][y] = new Tree(x, y);
			if (data[i].equals("TropicalTree"))
				Fields[x][y] = new TropicalTree(x, y);
			
			//artificial object
			if (data[i].equals("LadderUp"))
				Fields[x][y] = new LadderUp(x, y);
			if (data[i].equals("LadderDown"))
				Fields[x][y] = new LadderDown(x, y);
			
			//special
			if (data[i].equals("Plain"))
				Fields[x][y] = new PlainField(x, y);
			if (data[i].equals("SpawnField"))
				Fields[x][y] = new TropicalTree(x, y);
			if (data[i].equals("LavaHole"))
				Fields[x][y] = new LavaHole(x, y);

			// Fences :
			// 1-Line
			if (data[i].equals("FenceNorth"))
				Fields[x][y] = new FenceNorth(x, y);
			if (data[i].equals("FenceSouth"))
				Fields[x][y] = new FenceSouth(x, y);
			if (data[i].equals("FenceEast"))
				Fields[x][y] = new FenceEast(x, y);
			if (data[i].equals("FenceWest"))
				Fields[x][y] = new FenceWest(x, y);
			// 2-Line
			if (data[i].equals("FenceNE"))
				Fields[x][y] = new FenceNE(x, y);
			if (data[i].equals("FenceNW"))
				Fields[x][y] = new FenceNW(x, y);
			if (data[i].equals("FenceNS"))
				Fields[x][y] = new FenceNS(x, y);
			if (data[i].equals("FenceSE"))
				Fields[x][y] = new FenceSE(x, y);
			if (data[i].equals("FenceSW"))
				Fields[x][y] = new FenceSW(x, y);
			if (data[i].equals("FenceWE"))
				Fields[x][y] = new FenceWE(x, y);
			// 3-line
			if (data[i].equals("FenceNSE"))
				Fields[x][y] = new FenceNSE(x, y);
			if (data[i].equals("FenceNSW"))
				Fields[x][y] = new FenceNSW(x, y);
			if (data[i].equals("FenceNWE"))
				Fields[x][y] = new FenceNWE(x, y);
			if (data[i].equals("FenceSWE"))
				Fields[x][y] = new FenceSWE(x, y);


			// new Field
		}
	}

	private void createMonFromFile() {
		String[] data = new String[300];
		short lines = 0;

		try {
			File file = new File(new URL(MainApplet.applet.getCodeBase(),"data/MonData"
					+ mapLV).toURI());
			FileInputStream fileStream = new FileInputStream(file);
			DataInputStream dataStream = new DataInputStream(fileStream);
			BufferedReader fromFile = new BufferedReader(new InputStreamReader(
					dataStream));

			String strLine;
			// Read File Line By Line

			while ((strLine = fromFile.readLine()) != null) {
				if (!strLine.equals("")) {
					data[lines] = strLine;
					lines++;
					// System.out.println("|"+ data[lines-1] +"|");
				}
			}

			fromFile.close();
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}

		short j = 0;
		for (short i = 0; i < lines; i += 4) {
			int x = Integer.parseInt(data[i + 1]);
			int y = Integer.parseInt(data[i + 2]);
			int delay = Integer.parseInt(data[i + 3]);

			// System.out.println(" name: |"+ data[i]+"|");
			// System.out.println("    x:"+ data[i+1]);
			// System.out.println("    y:"+ data[i+2]);
			// System.out.println("delay:"+ data[i+3]);
			// System.out.println("    j:"+ j);
			// System.out.println("");

			//npcs
			if (data[i].equals("Joe"))
				npcs[j] = new TNPC.Joe(x, y, j);			
			
			//monster
			if (data[i].equals("Dragon"))
				npcs[j] = new Monster.Dragon(x, y, j);
			if (data[i].equals("Demon"))
				npcs[j] = new Monster.Demon(x, y, j);
			if (data[i].equals("Dude"))
				npcs[j] = new Monster.Dude(x, y, j);
			if (data[i].equals("Goblin"))
				npcs[j] = new Monster.Goblin(x, y, j);
			if (data[i].equals("Chicken"))
				npcs[j] = new Monster.Chicken(x, y, j);
			if (data[i].equals("kA"))
				npcs[j] = new Monster.kA(x, y, j);
			if (data[i].equals("MithrilDragon"))
				npcs[j] = new Monster.MithrilDragon(x, y, j);
			if (data[i].equals("Dog"))
				npcs[j] = new Monster.Dog(x, y, j);
			if (data[i].equals("Phoenix"))
				npcs[j] = new Monster.Phoenix(x, y, j);
			if (data[i].equals("BigGoblin"))
				npcs[j] = new Monster.BigGoblin(x, y, j);
			if (data[i].equals("Ankou"))
				npcs[j] = new Monster.Ankou(x, y, j);
			if (data[i].equals("Big_kA"))
				npcs[j] = new Monster.Big_kA(x, y, j);
			if (data[i].equals("Jad"))
				npcs[j] = new Monster.Jad(x, y, j);
			// new NPC

			npcs[j].setActive(delay);
			incrNPCNum();
			j++;
		}
	}
	
	public void setMonsterActivity(boolean state) {
		for (short i = 0; i < npcNum; i++) {
			npcs[i].setActive(state);
		}
	}

	public void drawMap(int spaceLeft, int spaceTop, Graphics g) {
		initMaxFields();

		for (short i = 0; i < maxFieldsX + 2; i++) {
			for (short j = 0; j < maxFieldsY + 2; j++) {
				g.drawImage(BasicMapField.getStaticImage(), 30 * (i - 1)
						+ spaceLeft, 30 * (j - 1) + spaceTop,MainApplet.applet);
				if (Fields[mapX + i][mapY + j].isNotBasic)
					g.drawImage(Fields[mapX + i][mapY + j].getImage(), 30
							* (i - 1) + spaceLeft, 30 * (j - 1) + spaceTop,MainApplet.applet);
			}
		}
		
		// <-- For Debugging
		// g.drawLine(60, 60+10, 60, 150+10);
		// g.drawLine(60, 150+10, 150, 150+10);
		// g.drawLine(150, 150+10, 150, 60+10);
		// g.drawLine(150, 60+10, 60, 60+10);
		// -->

		for (short i = 0; i < npcNum; i++) {
			// System.out.println ("i : "+i);
			// System.out.println("map.drawMap : for -> i = "+i);
			// System.out.println("map.drawMap : for -> NPC Num = "+npcNum);

			Image pic = npcs[i].getImage30();
			int x = npcs[i].getPosX();
			int y = npcs[i].getPosY();

			g.drawImage(pic, 30 * (x - 1) + spaceLeft, 30 * (y - 1) + spaceTop,MainApplet.applet);
		}
	}

	public void setPosition(int x, int y) {
		mapX = (short) x;
		mapY = (short) y;
	}
	
	public void repaint () {
		MainApplet.getGamePanel().fieldScreen().repaint();
	}

	public void setCurrentField(short x, short y) {
		if (y < 1) {
			MainApplet.actPlayer.move((short) 4);
			MainApplet.addInfo("There's no way I can go there ...");
		}
		if (x < 1) {
			MainApplet.actPlayer.move((short) 3);
			MainApplet.addInfo("There's no way I can go there ...");
		}

		currentField.exited();
		currentField = Fields[x][y];
		currentField.entered();

		//MainProg.GameWin.setTitle("Current Position : " + x + " | " + y);

		checkPlayerPos();
	}

	public void incrMapX() {
		mapX++;
		MainApplet.actPlayer.changePosX(-1);
		for (short i = 0; i < npcNum; i++) {
			npcs[i].posX--;
		}
		// printMapXY ();
	}

	public void decrMapX() {
		if (mapX > 0) {
			mapX--;
			MainApplet.actPlayer.changePosX(1);
			for (short i = 0; i < npcNum; i++) {
				npcs[i].posX++;
			}
		} else {
			System.out.println("Can not decrease MapX anymore.");
		}
		// printMapXY ();
	}

	public void incrMapY() {
		mapY++;
		MainApplet.actPlayer.changePosY(-1);
		for (short i = 0; i < npcNum; i++) {
			npcs[i].posY--;
		}
		// printMapXY ();
	}

	public void decrMapY() {
		if (mapY > 0) {
			mapY--;
			MainApplet.actPlayer.changePosY(1);
			for (short i = 0; i < npcNum; i++) {
				npcs[i].posY++;
			}
		} else {
			System.out.println("Can not decrease MapY anymore.");
		}
		// printMapXY ();
	}

	public void printMapXY() {
		System.out
				.println("Map Position on World Map : " + mapX + " | " + mapY);
	}

	public int getMapX() {
		return mapX;
	}
	public int getMapY() {
		return mapY;
	}

	public void incrMapLV() {
		mapLV++;
	}
	public void decrMapLV() {
		mapLV--;
	}
	public int getMapLV() {
		return (int) mapLV;
	}

	public String getNameOfField(int x, int y) {
		return Fields[x][y].getName();
	}

	public void incrNPCNum() {
		npcNum++;
	}

	public void checkPlayerPos() {
		short x = (short) MainApplet.actPlayer.getPosX();
		short y = (short) MainApplet.actPlayer.getPosY();

		if (x > maxFieldsX)
			incrMapX();
		if (x < 1)
			decrMapX();
		if (y > maxFieldsY)
			incrMapY();
		if (y < 1)
			decrMapY();
	}

	public static short checkMove(int x, int y, int dir) {
		int tempMapX = x;
		int tempMapY = y;
		int tempDir = 0;
		switch (dir) {
		case 1:
			tempMapX -= 1;
			tempDir = 3;
			break; // left
		case 2:
			tempMapY -= 1;
			tempDir = 4;
			break; // up
		case 3:
			tempMapX += 1;
			tempDir = 1;
			break; // right
		case 4:
			tempMapY += 1;
			tempDir = 2;
			break; // down
		default:
			return 0;
		}

		if (tempMapX <= 0) {
			return -1;
		}
		if (tempMapX >= 500) {
			return -1;
		}
		if (tempMapY <= 0) {
			return -1;
		}
		if (tempMapY >= 500) {
			return -1;
		}

		// System.out.println ("Field ["+mapX+"]["+mapY+"] accessible from " +
		// dir + " : " + MainProg.map.Fields[mapX][mapY].checkAccessible(dir));

		if (!MainApplet.map.Fields[x][y].checkAccessible(dir)) { // If start field
			// isn't
			// leavable
			// System.out.println ("Field not accessible"); // trough this
			// direction
			return 0;
		}

		if (!MainApplet.map.Fields[tempMapX][tempMapY].checkAccessible(tempDir)) { // If
			// target
			// field
			// isn't
			// accessible
			// System.out.println ("Field not accessible"); // trough this
			// direction
			return 0;
		}
		return 1;
	}

	public String getNameOfOwner(int x, int y) {
		int id_of_owner = Fields[x][y].getOwnerID();
		if (id_of_owner == -1)
			return "";

		return npcs[id_of_owner].getName();
	}

	public NPC getOwner(int x, int y) {
		int id_of_owner = Fields[x][y].getOwnerID();
		if (id_of_owner > -1) {
			return npcs[id_of_owner];
		} else {
			return null;
		}
	}
	
	public void changeLV (byte k) {
		this.mapLV += k;
		
		// clear arrays :
		for (short i = 0; i < 500; i++) {
			for (short j = 0; j < 500; j++) {
				Fields[i][j] = new BasicMapField(i, j);
			}
		}
		for (int i=0;i<100;i++) {
			npcs[i] = null;
		}
		npcNum = 0;
		
		// store data of the new map lv :
		createMapFromFile();
		createMonFromFile();
		repaint();
		
		System.out.println("Map LV changed to : "+mapLV);
	}
}
