package MainPackage;

import java.util.Calendar;
import java.awt.Graphics;
import java.awt.Image;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

import Items.Item;
import Monster.NPC;

public class Player {
	String fileName;
	private short posX;
	private short posY;
	
	private short mapX;
	private short mapY;
	
	private short pointingDir = 0; // pointing direction
	
	private String name;
	private String password;
	short lv;	// not used till now ...
	int xp;
	long points;
	
	private short max_hp;
	private short mom_hp;
	
	private short defence; // defence LV
	private short attack;  // attack  LV
	
	private long defenceXP;
	private long attackXP;
	
	private int coins;
	
	private InventoryManager inv;
	
	// for pausing between moves :
	private long timeOfLastMove = 0;
	private short pauseBeetweenMove = 150;
	
	private boolean walkedOutOfMap = false;
	
	// for dynamic map :
	public int mapXofMap;
	public int mapYofMap;
	
	private Image pic;
	
	// for fighting
	@SuppressWarnings("unused")
	private CombatWindow cbWin;
	private boolean isInAction = false;
	
	// for LVup-messages :
	private boolean[] lvdUp = new boolean[3];
	private short skillAmount = 2;
	
	/* Quest Variabels -->*/
	public byte cocoMilk;

	/* <--- */
	
	
	
	public String getName () {	
		return this.name;
	}
	public Image getImage () {
		return this.pic;
	}
	public short getLV () {	
		return lv;
	}
	public long getPoints () {	
		return points;
	}
	public short getMaxHP () {	
		return max_hp;
	}
	public short getMomHP () {	
		return mom_hp;
	}
	public short getDef () {	
		return defence;
	}
	public int getTotalDef () {
		return (defence+inv.getTotalDefenceBonus());
	}
	public short getAtk () {	
		return attack;
	}
	public int getTotalAtk () {
		return (attack+inv.getTotalAttackBonus());
	}
	public int getCoins () {
		return coins;
	}

	public InventoryManager getInventoryManager () {
		return this.inv;
	}
	
	public int getMapX () {
		return mapX;
	}public int getMapY () {
		return mapY;
	}
	public int getPosX () {
		return posX;
	}public int getPosY () {
		return posY;
	}
	public void changePosX (int x) {
		posX += x;
	}
	public void changePosY (int x) {
		posY += x;
	}

	//constructor
	public Player (String username, String passwordEntered) {
	    name = username;
	    password = passwordEntered;
	    lv = 1;
	    points = 0L;
	    max_hp = 100;
	    mom_hp = 100;
	    attackXP = 0;
	    defenceXP = 0;
	    coins = 0;
	    posX = 1;
	    posY = 1;
	    mapX = 1;
	    mapY = 1;
	    mapXofMap = 0;
	    mapYofMap = 0;
	    
	    /*Quests*/
	    cocoMilk = 0;
	    
	    attack = (short) XPLVconverter.getLV(attackXP);
	    defence = (short) XPLVconverter.getLV(defenceXP);
	    
	    this.pic = MainApplet.applet.getImage(MainApplet.applet.getCodeBase(),"pics/player/niels.png");
	    if (this.name.equals("umer"))
	    	 this.pic = MainApplet.applet.getImage(MainApplet.applet.getCodeBase(),"pics/player/Eye_of_the_Sword.png");
	    
	    inv = new InventoryManager ();
	    for (int i=0;i<30;i++)
	    	inv.setItem("",i);
	    
	    //System.out.println ("player.construct :: lenght of data[] = "+data.length);
	    
	    for (int i=0;i<10;i++) {
	    	try {
	    		inv.setItemEq("",i);
	    		//System.out.println ("player.construct :: data[44+i] = "+data[44+i]);
	    	} catch (Exception e) {
	    		System.out.println ("Error in player.consrtuct :: i = "+i);
	    		System.out.println (e.toString());
	    		inv.setItemEq("",i);
	    	}
	    }
	    
	    
	}
	public boolean setIdentitiy (String username, String password) {
		fileName = "data/UserData/"+ username + ".txt";
		File userFile = MainApplet.getFile(fileName);
		
		if ((!userFile.exists()) || (!userFile.isFile())) {
			MainApplet.applet.alert("Player doesn't exist");
			return false;
		}
		
		String[] data = new String[100];
		
	    try{
	    	FileInputStream fileStream = new FileInputStream(fileName);
	    	DataInputStream dataStream = new DataInputStream(fileStream);
	    	BufferedReader fromFile = new BufferedReader(new InputStreamReader(dataStream));
	    	   
	    	String strLine; 
	    	short i = 0;
	    	//Read File Line By Line
	    	
	    	while ((strLine = fromFile.readLine()) != null)   {
	    		data[i] = strLine;
	    		i++ ;
	    	}

	    	fromFile.close();
	    }catch (Exception e){
	    	System.err.println("Error: " + e.getMessage());
	    }
	    
	    //System.out.println ("Password (entered) : \"" + password + "\"");
	    //System.out.println ("Password (real)    : \"" + data[1] + "\"");
	    
	    if (!password.equals(data[1])) {
	    	MainApplet.applet.alert("Wrong Password");
	    	MainApplet.playerValid = false;
	    	return false;
	    }	
		
	    name = data[0];
	    this.password = data[1];
	    lv = 1;
	    points = Long.parseLong(data[4]);
	    max_hp = Short.parseShort(data[2]);
	    mom_hp = Short.parseShort(data[3]);
	    attackXP = Long.parseLong(data[5]);
	    defenceXP = Long.parseLong(data[6]);
	    coins = Integer.parseInt(data[7]);
	    posX = Short.parseShort(data[8]);
	    posY = Short.parseShort(data[9]);
	    mapX = Short.parseShort(data[10]);
	    mapY = Short.parseShort(data[11]);
	    mapXofMap = Integer.parseInt(data[12]);
	    mapYofMap = Integer.parseInt(data[13]);
	    cocoMilk = Byte.parseByte(data[54]);
	    
	    attack = (short) XPLVconverter.getLV(attackXP);
	    defence = (short) XPLVconverter.getLV(defenceXP);
	    
	    this.pic = MainApplet.getImage("pics/player/niels.gif");
	    if (this.name.equals("umer"))
	    	 this.pic = MainApplet.getImage("pics/player/Eye_of_the_Sword.gif");
	    
	    inv = new InventoryManager ();
	    for (int i=0;i<30;i++)
	    	inv.setItem(data[14+i],i);
	    
	    for (int i=0;i<10;i++) {
	    	try {
	    		inv.setItemEq(data[44+i],i);;
	    	} catch (Exception e) {
	    		System.out.println ("Error in player.consrtuct :: i = "+i);
	    		System.out.println (e.toString());
	    		inv.setItemEq("",i);
	    	}
	    }
	    MainApplet.getGamePanel().invScreen().setManager(inv);
	    MainApplet.getGamePanel().equipScreen().setManager(inv);
	    MainApplet.getGamePanel().infoScreen().name.setText(username);
	    
		MainApplet.applet.alert("Log In succesfull. Welcome " + username + "!");
		return true;
	}
	public void saveData () {
		try {			
			
			// delete and re-create file :
			
			File aFile = MainApplet.getFile(fileName);
			aFile.delete();
			aFile.createNewFile();
			
			// write into file :
	
		    try {
		    	
		        BufferedWriter toFile = new BufferedWriter(new FileWriter(fileName));
		        toFile.write(name);toFile.newLine();											// user name
		        toFile.write(password);toFile.newLine();										// password
		        toFile.write(MainApplet.parseString(max_hp));toFile.newLine();					// maximal hit points
		        toFile.write(MainApplet.parseString(mom_hp));toFile.newLine();					// current hit points
		        toFile.write(String.valueOf(points));toFile.newLine();							// Points
		        toFile.write(String.valueOf(attackXP));toFile.newLine();						// Attack XP
		        toFile.write(String.valueOf(defenceXP));toFile.newLine();						// Defence XP
		        toFile.write(String.valueOf(coins));toFile.newLine();							// Coins
		        toFile.write(MainApplet.parseString(posX));toFile.newLine();			 		// posX
		        toFile.write(MainApplet.parseString(posY));toFile.newLine();					// posY
		        toFile.write(MainApplet.parseString(mapX));toFile.newLine();					// worldMapX
		        toFile.write(MainApplet.parseString(mapY));toFile.newLine();					// worldMapY
		        toFile.write(String.valueOf(MainApplet.map.getMapX()));toFile.newLine();		// map's mapX
		        toFile.write(String.valueOf(MainApplet.map.getMapY()));toFile.newLine();		// map's mapY		        

		        try {
		        	inv.writeInventoryIntoFile(toFile);
		        } catch (Exception e) {
		        	System.out.println ("Exception in player.saveData : " + e.toString());
		        	for (short i=0;i<40;i++) {	// 40 items = 30 inventory + 10 equip
		        		toFile.write("Empty");toFile.newLine();
		        	}
		        }
		        toFile.write(String.valueOf(cocoMilk));toFile.newLine();
		        
		        toFile.close();
		        
		        //MainProg.alert("Data Saved");
		    } catch (IOException e) {
		    	System.out.println (e) ;
		    }
			
		} catch (Exception e) {
			System.out.println(e);
		}	
	}	
	
	public void logOut () {
		saveData();
	}


	public void move (short dir) {
		//System.out.println("Player.move :: moving into direction "+dir);
		
		if (isInAction)
			return;
		
	    Calendar now = Calendar.getInstance();
	    
	    long tempL = now.getTimeInMillis();
	    if (!(tempL >= timeOfLastMove + pauseBeetweenMove)) {
	    	//System.out.println("Player.move :: You may not move this often; returning...");
	    	return;
	    }
		
	    timeOfLastMove = tempL;
	    
	    short movePossible = Map.checkMove(mapX, mapY, dir);
	    //System.out.println("Player.move :: movePossbile : "+movePossible);
		if (movePossible != 1) {
			if (movePossible == -1) {
				if (!walkedOutOfMap)
					MainApplet.addInfo("There's no way I can go there ...");
				walkedOutOfMap = true;
			}
			return;
		}
			
		switch (dir) {
			case 1 : posX -= 1; mapX -= 1; break; // left
			case 2 : posY -= 1; mapY -= 1; break; // up
			case 3 : posX += 1; mapX += 1; break; // right
			case 4 : posY += 1; mapY += 1; break; // down
			default : return;
		}
		pointingDir = dir;
		MainApplet.map.setCurrentField(mapX,mapY);
		
		MainApplet.map.repaint();
		
		walkedOutOfMap = false;
		
		String temp = MainApplet.map.getNameOfOwner(mapX, mapY);
		if (temp.equals("")) {
			return;
		} else {
			// start fighting :
			NPC tempNPC = MainApplet.map.getOwner(mapX, mapY);
			startFightWith (tempNPC);
		}
		//MainProg.GameWin.infoScreenAction.addInfo("You're on a "+temp);
	}

	public void startFightWith (NPC monster) {

		//System.out.println(tempNPC);
		cbWin = new CombatWindow(this, monster);
		isInAction = true;
		// --
		for (short i=1; i<= skillAmount; i++)
			lvdUp[i] = false;	
	}
	
	public void changeHP (short difference) {
		addToHP (difference);
	}
	
	public void changeHP (int difference) {
		addToHP ((short) difference);
	}
	private void addToHP (short difference) {
		if ((difference > 0)&&(mom_hp == max_hp)) {
			mom_hp = max_hp;
			MainApplet.addInfo("You already have full HP");
			return;
		}
		mom_hp += difference;
		if (mom_hp <= 0)
			die();

		//System.out.println ("Current HP : " + mom_hp);
		MainApplet.getGamePanel().infoScreen().refresh();
		MainApplet.map.repaint();		
	}

	public void changeHP_noCheck (int difference, Object sender) {
		String cos = sender.getClass().toString(); // cos = class of sender
		cos = cos.substring(6,cos.length());
		//System.out.println("player.kill : cos = " + cos);
		// Sender wird �berpr�ft, damit nicht nicht jede Klasse den player killen kann, sonst w�rs ja zu easy f�r Hacker (dich,Niels)
		if (!cos.equals("MainPackage.CombatWindow$actLis"))
			return;
		
		if ((difference > 0)&&(mom_hp == max_hp)) {
			mom_hp = max_hp;
			MainApplet.addInfo("You already have full HP");
			return;
		}
		mom_hp += difference;	
		
		//System.out.println ("Current HP : " + mom_hp);		
		MainApplet.map.repaint();	
	}
	
	public void setInAction (boolean state) {
		this.isInAction = state;
	}
	
	private void die () {
		mom_hp = max_hp;
		posX = 3;
		posY = 3;
		mapX = 3;
		mapY = 3;
		pointingDir = 0;
		
		short i = 0;
		while (i < 3) {
			int position = MainApplet.getRandom(0, 29);
			if (this.inv.destroyItem(position))
				i++;
		}
		
		
		MainApplet.map.setPosition(0,0);
		MainApplet.addInfo("You died and lost 3 items...");
		MainApplet.applet.alert("You died");
	}
	public void kill (Object sender) {
		String cos = sender.getClass().toString(); // cos = class of sender
		cos = cos.substring(6,cos.length());
		//System.out.println("player.kill : cos = " + cos);
		// Sender wird �berpr�ft, damit nicht nicht jede Klasse den player killen kann, sonst w�rs ja zu easy f�r Hacker (dich,Niels ^^)
		if (cos.equals("MainPackage.CombatWindow$actLis"));
			die();
	}
	
	public void destroyCbWin () {
		this.cbWin = null;
		this.isInAction = false;
		this.showLVupMessages ();
	}
	
	public void paint (Graphics g) {
		short x = (short) ((posX-1)*30);
		short y = (short) ((posY-1)*30);
		
		//System.out.println(posX + "|"+ posY);
		
		Image temp;
		String tempS = "pics/player/moving/";
		
		//System.out.println ("pointing direction : " + pointingDir);
		
		switch (pointingDir) {
			case 1  : temp = MainApplet.applet.getImage(MainApplet.applet.getCodeBase(),tempS+"person_links.gif");break; 		// links
			case 2  : temp = MainApplet.applet.getImage(MainApplet.applet.getCodeBase(),tempS+"person_oben.gif");break;  	 	// oben
			case 3  : temp = MainApplet.applet.getImage(MainApplet.applet.getCodeBase(),tempS+"person_rechts.gif");break; 	// rechts
			case 4  : temp = MainApplet.applet.getImage(MainApplet.applet.getCodeBase(),tempS+"person_unten.gif");break;   	// unten
			default : temp = MainApplet.applet.getImage(MainApplet.applet.getCodeBase(),tempS+"person_vorne.gif");break;	 	// default
		}
		
		g.drawImage(temp, x, y, MainApplet.applet);
		
		//g.fillOval(x,y, 30, 30);
	}

	public boolean addXP (String skill, int xp) {
		
		// returns true when player lvsUp, otherwise not
		
		System.out.println("player.addXP : skill = "+skill+" ; xp="+xp);
		int curAtk = this.attack;
		int curDef = this.defence;
		
		if (xp<1)		// You may not add decrease XP by giving a number < 0 / if xp == 0, it doesn't change anyways...
			return false;
		
		if (skill.equals("Attack"))
			attackXP += xp;
		if (skill.equals("Defence"))
			attackXP += xp;
		
		refreshLVs();
		
		boolean lvUp = false;
		if (attack != curAtk)
			addLVupMessage (1);
		if (defence != curDef)
			addLVupMessage (2);
		return lvUp;
	}
	
	private void refreshLVs () {
		attack =  (short) XPLVconverter.getLV (attackXP);
		defence =  (short) XPLVconverter.getLV (defenceXP);
	}

	public void addLVupMessage (String skill) {
		addLVupMessage (getSkillCode(skill));
	}
	public void addLVupMessage (int skillCode) {
		if (skillCode > skillAmount)
			return;
		
		lvdUp[skillCode] = true;
	}
	
	private void showLVupMessages () {
		for (short i = 1; i <= skillAmount; i++) {

			if (lvdUp[i]) {
				int tempLV = getLVbySkill (getSkillName(i));
				MainApplet.applet.alert("Congratulations !\nYou just leveled Up in " + getSkillName((int) i) + "!\n\nYou have now reached lv " + tempLV + " !");
			}
		}
	}	
	
	private int getLVbySkill (String skill) {
		if (skill.equalsIgnoreCase("attack"))
			return attack;
		if (skill.equalsIgnoreCase("defence"))
			return defence;
		
		return 0;
	}
	
	
	private int getSkillCode (String skill) {
		if (skill.equalsIgnoreCase("attack"))
			return 1;
		if (skill.equalsIgnoreCase("defence"))
			return 2;
		return 0; 	// default
	}
	private String getSkillName (int code) {
		if (code > skillAmount)
			return "";
		if (code < 1)
			return "";
		
		switch (code) {
			case 1 : return "Attack";
			case 2 : return "Defence";
			default : return "";
		}
	}
	
	public void addPoints (int x) {
		this.points += x;
		if (this.points < 0)
			this.points = 0;
	}

	public void addCoins (int x) {
		this.coins += x ;
	}
	
	public void addItem (Item item) {
		//System.out.println ("OP_GB.player.addItem :: item : "+item.getName());
		boolean itemAdded = this.inv.addItem (item);
		if (!itemAdded)
			MainApplet.addInfo("You don't have enough space to pick up another "+item.getName()+".");
	}
	
	
	// for a special item (Energy Potion):
	public void setPauseBeetweenMove (int pause, long time, Object sender) {
		String cos = sender.getClass().toString(); // cos = class of sender
		cos = cos.substring(6,cos.length());
		// Hacker-Prevention
		if (cos.equals("Items.EnergyPotion")) {
			//System.out.println ("OP_GB.player.setPauseBeetwenMove :: OK , sender is valid ");
			pauseBeetweenMove = (short) pause;
			new aThread(time).start();
		}
	}
	private void setPauseBeetweenMoveToDefault (aThread sender) {
		pauseBeetweenMove = 150;
		sender = null;	// destroy thread afterwards
	}
	private class aThread extends Thread {
		private long time;
		
		public aThread (long time) {
			super();
			this.time = time;
		}
			
		public void run () {
			try { sleep(time); } catch (Exception e) {}
			setPauseBeetweenMoveToDefault(this);
		}
	}
}