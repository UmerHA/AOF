package MapFields;

import java.awt.Image;

public class BasicMapField extends MapField {
	
	private static Image pic;
	
	public BasicMapField (short x, short y) {
		//super (x,y,"pics/fields/BasicMapFieldImage.jpg");
		super (x,y,"pics/fields/grass.jpg");
		isNotBasic = false;
		pic = this.getImage();
	}
	public BasicMapField (int x, int y) {
		super (x,y,"pics/fields/grass.jpg");
		isNotBasic = false;
		pic = this.getImage();
	}
	
	public void entered () {
		// System.out.println ("I've been entered : " + this.x + " " + this.y);
	}
	
	public static Image getStaticImage () {
		return pic;
	}
}
