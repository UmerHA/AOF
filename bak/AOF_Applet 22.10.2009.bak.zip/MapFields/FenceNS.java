package MapFields;

public class FenceNS extends MapField {
	public FenceNS (short x, short y) {
		super (x,y,"pics/fields/Fences/FenceNS.png");
		accessibleNorth = false;
		accessibleSouth = false;
	}
	public FenceNS (int x, int y) {		
		super(x,y, "pics/fields/Fences/FenceNS.png");
		accessibleNorth = false;
		accessibleSouth = false;
	}
}
