package MapFields;

public class FenceSE extends MapField {
	public FenceSE (short x, short y) {
		super (x,y,"pics/fields/Fences/FencesSE.png");
		accessibleSouth = false;
		accessibleEast = false;
	}
	public FenceSE (int x, int y) {		
		super(x,y, "pics/fields/Fences/FenceSE.png");
		accessibleSouth = false;
		accessibleEast = false;
	}
}
