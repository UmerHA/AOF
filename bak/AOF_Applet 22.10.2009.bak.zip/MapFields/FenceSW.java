package MapFields;

public class FenceSW extends MapField {
	public FenceSW (short x, short y) {
		super (x,y,"pics/fields/Fences/FenceSW.png");
		accessibleSouth = false;
		accessibleWest = false;
	}
	public FenceSW (int x, int y) {		
		super(x,y, "pics/fields/Fences/FenceSW.png");
		accessibleSouth = false;
		accessibleWest = false;
	}
}
