package MapFields;

public class FenceSWE extends MapField {
	public FenceSWE (short x, short y) {
		super (x,y,"pics/fields/Fences/FenceSWE.png");
		accessibleSouth = false;
		accessibleWest = false;
		accessibleEast = false;
	}
	public FenceSWE (int x, int y) {		
		super(x,y, "pics/fields/Fences/FenceSWE.png");
		accessibleSouth = false;
		accessibleWest = false;
		accessibleEast = false;
	}
}