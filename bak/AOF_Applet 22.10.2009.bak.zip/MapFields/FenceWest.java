package MapFields;




public class FenceWest extends MapField {
	public FenceWest (short x, short y) {
		super (x,y,"pics/fields/Fences/FenceWest.png");
		accessibleWest = false;
	}
	public FenceWest (int x, int y) {		
		super(x,y, "pics/fields/Fences/FenceWest.png");
		accessibleWest = false;
	}
}
