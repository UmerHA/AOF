package MapFields;

import MainPackage.MainApplet;

public class LadderDown extends MapField {
	public LadderDown (short x, short y) {
		super (x,y,"pics/fields/LadderDown.gif");
		this.setOpenForNPC(false);
	}
	public LadderDown (int x, int y) {		
		super(x,y, "pics/fields/LadderDown.gif");
		this.setOpenForNPC(false);
	}
	
	public void entered () {
		MainApplet.addInfo("You climb down the ladder.");
		MainApplet.map.changeLV((byte)-1);
		MainApplet.actPlayer.changePosX(1);
	}
}
