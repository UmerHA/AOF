package MapFields;

import MainPackage.MainApplet;

public class LadderUp extends MapField {
	public LadderUp (short x, short y) {
		super (x,y,"pics/fields/LadderUp.gif");
		this.setOpenForNPC(false);
	}
	public LadderUp (int x, int y) {		
		super(x,y, "pics/fields/LadderUp.gif");
		this.setOpenForNPC(false);
	}
	
	public void entered () {
		MainApplet.addInfo("You climb up the ladder.");
		MainApplet.map.changeLV((byte)1);
		MainApplet.actPlayer.changePosX(1);
	}
}
