package MapFields;

import java.awt.Image;
import MainPackage.MainApplet;

public class MapField {
	String name;
	
	private Image mapImage;
	String mapImageName;
	
	short x;
	short y;
	
	boolean accessibleNorth = true;
	boolean accessibleSouth = true;
	boolean accessibleEast = true;
	boolean accessibleWest = true;
	
	public boolean isNotBasic = true;
	private boolean isTakeByNPC = false;
	protected boolean openForNPC = true;
	
	private int takenBy = -1;
	
	public MapField (short x, short y, String picPath) {
		constructor (x,y,picPath);	
	}
	public MapField (int x, int y, String picPath) {
		constructor ((short) x,(short) y,picPath);		
	}
	
	private void constructor (short x, short y, String picPath) {
		this.x = x;
		this.y = y;
		this.mapImageName = picPath;
		this.mapImage = MainApplet.applet.getImage(MainApplet.applet.getCodeBase(), picPath);
	}
	
	public boolean checkAccessible (int dir) {
		return checkAccess((short) dir);
	}
	public boolean checkAccessible (short dir) {
		return checkAccess (dir);
	}
	public boolean checkAccessible (String dir) {
		short direction = 0;
		if (dir.equalsIgnoreCase("west"))
			direction = 1;
		if (dir.equalsIgnoreCase("north"))
			direction = 2;
		if (dir.equalsIgnoreCase("east"))
			direction = 3;
		if (dir.equalsIgnoreCase("south"))
			direction = 4;
		
		if (direction == 0)
			System.out.println ("No valid direction given");
		
		return checkAccess (direction);
	}
	
	private boolean checkAccess (short dir) {
		switch (dir) {	
			case 1 : if (accessibleWest) {return true;} else {return false;}
			case 2 : if (accessibleNorth) {return true;}else {return false;}
			case 3 : if (accessibleEast) {return true;} else {return false;}
			case 4 : if (accessibleSouth) {return true;}else {return false;}
			default : return false;
		}

	}
	
	public void entered () {		}
	public void exited () {}
	
	public Image getImage () {
		return mapImage;
	}
	public boolean isTaken () {
		return this.isTakeByNPC;
	}
	public void take (int taker_id) {
		this.isTakeByNPC = true;
		this.takenBy = taker_id;
	}
	public void free () {
		this.isTakeByNPC = false;
		this.takenBy = -1; // default, -1 hei�t nicht besetzt
	}
	
	public boolean isOpenForNPC() {
		return openForNPC;
	}
	public void setOpenForNPC( boolean state) {
		this.openForNPC = state;
	}
	public int getOwnerID () {
		return this.takenBy;
	}
	public String getName () {
		String temp = this.getClass().toString();
		return temp.substring(16, temp.length());
	}
}
