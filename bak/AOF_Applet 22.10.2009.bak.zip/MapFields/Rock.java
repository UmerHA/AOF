package MapFields;

public class Rock extends MapField {

	public Rock(short x, short y) {
		super(x, y, "pics/fields/Rock.png");
		accessibleNorth = false;
		accessibleSouth = false;
		accessibleEast = false;
		accessibleWest = false;
	}

	public Rock(int x, int y) {
		super(x, y, "pics/fields/Rock.png");
		accessibleNorth = false;
		accessibleSouth = false;
		accessibleEast = false;
		accessibleWest = false;
	}

	public void entered() {
		System.out.println("Rock entered ?! Strange ...");
	}

	public void exited() {
		System.out.println("Rock says : Don't leave me ");
	}
}
