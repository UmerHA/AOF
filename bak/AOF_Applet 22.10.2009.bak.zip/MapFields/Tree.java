package MapFields;

public class Tree extends MapField {

	public Tree(short x, short y) {
		super(x, y, "pics/fields/Tree.png");
		accessibleNorth = false;
		accessibleSouth = false;
		accessibleEast = false;
		accessibleWest = false;
	}

	public Tree(int x, int y) {
		super(x, y, "pics/fields/Tree.png");
		accessibleNorth = false;
		accessibleSouth = false;
		accessibleEast = false;
		accessibleWest = false;
	}
}
