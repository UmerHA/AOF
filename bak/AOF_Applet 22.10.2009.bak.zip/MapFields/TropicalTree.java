package MapFields;

import MainPackage.MainApplet;

public class TropicalTree extends MapField {

	public TropicalTree(short x, short y) {
		super(x, y, "pics/fields/TropicalTree.gif");
		accessibleNorth = false;
		accessibleSouth = false;
		accessibleEast = false;
		accessibleWest = false;
	}

	public TropicalTree(int x, int y) {
		super(x, y, "pics/fields/TropicalTree.gif");
		accessibleNorth = false;
		accessibleSouth = false;
		accessibleEast = false;
		accessibleWest = false;
	}
	
	public void use () {
		MainApplet.actPlayer.addItem(new Items.Coconut());
		MainApplet.addInfo("You pick a fresh coconut");
	}
}