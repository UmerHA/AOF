package MapFields;

public class Water1 extends MapField {
	public Water1 (short x, short y) {
		super (x,y,"pics/fields/Water1.gif");
		this.setOpenForNPC(false);
	}
	public Water1 (int x, int y) {		
		super(x,y, "pics/fields/Water1.gif");
		this.setOpenForNPC(false);
	}
	
	public void entered () {
		new Water(0,0).entered();	// die Zahlen da sind egal, es kann auch zB 8 45
	}
	public void exited () {
		new Water(0,0).exited();	// die Zahlen da sind egal, es kann auch zB 8 45
	}
}
