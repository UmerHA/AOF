package MapFields;

import MainPackage.MainApplet;

public class Water2 extends MapField {
	public Water2(short x, short y) {
		super(x, y, "pics/fields/Water2.jpg");
		this.openForNPC = false;

	}

	public Water2(int x, int y) {
		super(x, y, "pics/fields/Water2.jpg");
		this.openForNPC = false;

	}

	public void entered() {

		short mom_hp = MainApplet.actPlayer.getMomHP();
		short max_hp = MainApplet.actPlayer.getMaxHP();
		MainApplet.addInfo("You drink some water ...");
		if (mom_hp == max_hp) {
			MainApplet.actPlayer.changeHP((short) 10);
		} else if (mom_hp > max_hp - 10) {
			int diff = max_hp - mom_hp;
			MainApplet.addInfo("You gain " + diff
					+ " HP");
			MainApplet.actPlayer.changeHP((short) diff);
		} else {
			MainApplet.addInfo("You gain 10 HP");
			MainApplet.actPlayer.changeHP((short) 10);
		}
	}

}
