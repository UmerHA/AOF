// Listen Thread

package Connection;

import java.io.*;
import java.net.*;

import MainPackage.ExternalPlayer;
import MainPackage.MainApplet;

public class ClientThread extends Thread {

	boolean DEBUG = true; // Debug f�r Umer :D
	static int BUFFSIZE = 128000;
	int port;

	BufferedInputStream input;

	protected int Handle(String in) {		
		System.out.println("Handle:" + in);
		
		String data[] = in.split("~");
		
		/*Handle data depending of prefix : */
		
		if (data[0].equals("Loin")) {//Log in
			if (data[1].equals("dne")) {//done
				MainApplet.map.create();
				MainApplet.applet.setContentPanel(1);
			} else if (data[1].equals("bafo")) {//bad format
				if (data[2].equals("un"))
					MainApplet.applet.alert("Wrong username!");
				if (data[2].equals("pw"))
					MainApplet.applet.alert("Wrong password!");
			} else if (data[1].equals("nf")) {//not found
				MainApplet.applet.alert("User does not exist!");
			} else if (data[1].equals("miss")) {//mistake
				if (data[2].equals("mloin"))
					MainApplet.applet.alert("This user is already logged in!");
				if (data[2].equals("wpw"))
					MainApplet.applet.alert("Wrong password!");	
				if (data[2].equals("ipmloin")) {
					MainApplet.applet.alert("To many connections fomr this ip");
					System.exit(0);
				}
			}
		}
		
		if (data[0].equals("upd")) {//update
			if (data[2].equals("on")) {
				MainApplet.addInfo(data[1] + " is now online.");
				ExternalPlayer.createNew(data[1]);
			} else if (data[2].equals("ofl")) {
				MainApplet.addInfo(data[1] + " is now offline.");
				ExternalPlayer.destroy(data[1]);
			} else {
				if(MainApplet.actPlayer.getName().equals("username"))
					MainApplet.actPlayer.setName(data[1]);								
				
				if (data[1].equals(MainApplet.actPlayer.getName())) {
					//System.out.println("Update : name = "+data[1]);
					//System.out.println("Update : x    = "+data[2]);
					//System.out.println("Update : y    = "+data[3]);
					//System.out.println("Update : mapLV= "+data[4]);
			
					MainApplet.actPlayer.setData(data[1], data[2], data[3], data[4]);
				} else {
					//MainApplet.addInfo(data[1] + " just got updated.");
					System.out.println("ClientThread.handel :: "+in);
					ExternalPlayer.setPosition(data[1], data[2], data[3], "0");
				}
			}
		}	
		
		
		/* MESSAGE HANDLING : */
		if (data[0].equals("mss")) {
			if (data[1].equals("miss") && data[2].equals("no")) {
				System.exit(0);//not online
			} else {
				MainApplet.addInfo(data[1] + " : " + data[2]);//otherwise just show the recieved message
			}
		}
		if (data[0].equals("gmss")) {
			if (data[1].equals("miss") && data[2].equals("no")) {
				System.exit(0);//not online
			} else {
				MainApplet.addBlueInfo(data[1] + " : " + data[2]);//otherwise just show the recieved message
			}
		}
		if (data[0].equals("gmsw")) {
			if (data[1].equals("miss") && data[2].equals("no")) {
				System.exit(0);//not online
			} else {
				MainApplet.addBlueInfo(data[1] + " : " + data[2]);//otherwise just show the recieved message
			}
		}
		if (data[0].equals("msw")) {//whisper
			if (data[1].equals("miss") && data[2].equals("no")) {
				System.exit(0);//not online
			} else if (data[1].equals("miss") && data[2].equals("tno")){
				MainApplet.addInfo("Player not online");
			} else {
				MainApplet.addGreenInfo(data[1] + " : " + data[2]);//otherwise just show the recieved message
			}
		}
		
		/* MOVE HANDLING */
		if (data[0].equals("mve")) {	
			//System.out.println("ClientThread.handel :: mve - = "+data[1]);
			if (data[1].equals("dne"));
				MainApplet.actPlayer.moveByServer();
			if (data[1].equals("hck")) {
				System.out.println("Kicking");
				System.exit(0);//kick the speed hacker - muhaha
			}
		}
		
		/* FRIEND-LIST HANDLING*/
		if (data[0].equals("frl")) {
			
			String names = in.substring(4,in.length());
			MainApplet.actPlayer.updateFriendsList (names.split("~"));
		}
		
		/* INVENTORY/EQUIP-INVENTORY HANDLING */
		if (data[0].equals("invl")) {
			for (int i=0;i<30;i++) {
				MainApplet.actPlayer.getInventoryManager().setItem(Items.Item.getItemByID(Integer.parseInt(data[i+1])), i);
			}
		}
		if (data[0].equals("equil")) {
			for (int i=0;i<10;i++) {
				MainApplet.actPlayer.getInventoryManager().setItemEq(Items.Item.getItemByID(Integer.parseInt(data[i+1])), i);
			}
		}			
		
		return 0;
	}

	// bekommt nen string vom socket
	public String RecvString(char terminal) throws IOException {
		char c;
		String out;

		out = new String("");

		while ((c = (char) input.read()) != terminal)
			out = out + String.valueOf(c);
		return out;
	}

	public ClientThread(Socket sock) throws IOException {
		try {
			// sock = new Socket(InetAddress.getByName(address), port);
			input = new BufferedInputStream(sock.getInputStream(), BUFFSIZE);
			// output = new BufferedOutputStream(sock.getOutputStream(),
			// BUFFSIZE);
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Listen Thread gestartet");
	}

	public void run() {
		do {
			String in = new String("");
			try {
				in = RecvString('#');
			} catch (IOException e) {
				e.printStackTrace();
			}
			Handle(in);
		} while (true);
	}
}