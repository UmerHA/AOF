package MainPackage;

/* unfinished */

public class ConfirmMessage extends PopUp {
	private static final long serialVersionUID = 1L;

	public ConfirmMessage (String txt) {
		this.w = txt.length()*3 + 40;
		
	}
}
