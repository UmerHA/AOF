package MainPackage;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

import Panels.ChatPanel;
import Panels.InfoPanel;
import Panels.InventoryEquipPanel;
import Panels.InventoryPanel;
import Panels.OptionPanel;

public class GamePanel extends JPanel {
	private static final long serialVersionUID = 1L;

	private ChatBox chatbox;
	private JPanel mainScreen;
	private FieldPanel fieldScreen;
	private PanelSwitcher menuPanel;

	private InventoryPanel invScreen;
	private InventoryEquipPanel equipScreen;
	private InfoPanel infoScreen;
	private OptionPanel optScreen;
	private ChatPanel chatScreen;

	public GamePanel() {
		// create sub-panels -->
		mainScreen = new JPanel();
		menuPanel = new PanelSwitcher();
		invScreen = new InventoryPanel(MainApplet.actPlayer
				.getInventoryManager());
		equipScreen = new InventoryEquipPanel(MainApplet.actPlayer
				.getInventoryManager());
		infoScreen = new InfoPanel();
		optScreen = new OptionPanel();
		fieldScreen = new FieldPanel();
		chatScreen = new ChatPanel();
		chatbox = new ChatBox(this);

		// shape and add the sub-panels -->
		setLayout(new BorderLayout());

		mainScreen.setLayout(new BorderLayout());
		mainScreen.add(chatbox, "South");
		mainScreen.add(fieldScreen, "Center");
		
		menuPanel.addPanel(invScreen, "Inventory");
		menuPanel.addPanel(equipScreen, "Equipment");
		menuPanel.addPanel(infoScreen, "Stats");
		menuPanel.addPanel(optScreen, "Options");
		menuPanel.addPanel(chatScreen, "Chat");
		
		add(mainScreen, "Center");
		add(menuPanel, "East");

		// repositionComponents();

		// add listeners -->
		addMouseListener(new mLis());
	}

	public FieldPanel fieldScreen() {
		return this.fieldScreen;
	}
	public InventoryPanel invScreen() {
		return this.invScreen;
	}
	public InventoryEquipPanel equipScreen() {
		return this.equipScreen;
	}
	public OptionPanel optScreen() {
		return this.optScreen;
	}
	public ChatPanel chatScreen() {
		return this.chatScreen;
	}
	public PanelSwitcher menuPanel() {
		return this.menuPanel;
	}	
	public ChatBox chatbox() {
		return this.chatbox;
	}
	public InfoPanel infoScreen() {
		return this.infoScreen;
	}
	
	public void isNowActive() {
		MainApplet.map.recreateMap();
	}


	class mLis extends MouseAdapter {
		public void mousePressed(MouseEvent e) {
			grabFocus();
		}
	}

	public void repaint (Graphics g) {
		chatbox.repaint();
		mainScreen.repaint();
		infoScreen.repaint();
		fieldScreen.repaint();
		menuPanel.repaint();
	}

	/*
	 * Due to layout changes currently the menu panel does not support drag and drop.
	 * 
	 * //--->for MenuPanel //-> Drag & Drop private void repositionPanel () {
	 * menuPanel.setBounds(invX, invY, MP_WIDTH, MP_HEIGHT); invalidate();
	 * validate(); //System.out.println("GamePanel.repostionPanel"); } public
	 * void changePosition (int x, int y) { invX += x; invY += y;
	 * repositionPanel(); //System.out.println("GamePanel.changePosition"); }
	 * //<- public void setMenuPanelContent (int i) {//System.out.println(
	 * "GamePanel.setMenuPanelVisibility :: setting visibility to "+bool);
	 * boolean isMPVisible; isMPVisible = menuPanel.keyPressed((byte) i);
	 * 
	 * if (isMPVisible) { menuPanel.setBounds(invX, invY, MP_WIDTH, MP_HEIGHT);
	 * } else { menuPanel.setBounds(invX, invY, 0, 0); } invalidate();
	 * validate(); repaint(); } //<---
	 */
}