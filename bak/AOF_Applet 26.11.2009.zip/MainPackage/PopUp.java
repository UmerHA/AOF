package MainPackage;

import javax.swing.JPanel;

/* unfinished */

public abstract class PopUp extends JPanel {
	private static final long serialVersionUID = 1L;
	
	protected int x,y;
	protected int w,h;
	protected short zIndex;
	public short zIndex() {
		return this.zIndex;
	}
}
