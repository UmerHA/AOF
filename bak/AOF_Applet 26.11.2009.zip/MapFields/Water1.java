package MapFields;

public class Water1 extends MapField {
	public Water1(int x, int y) {
		super(x, y, "pics/fields/Water1.gif");
		this.openForNPC = false;
	}
}
