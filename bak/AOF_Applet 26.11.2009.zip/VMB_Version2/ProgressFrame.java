package VMB_Version2;

import javax.swing.JFrame;
//import javax.swing.JProgressBar;

public class ProgressFrame extends JFrame {
	private static final long serialVersionUID = 1L;

	public ProgressFrame () {
		//Where member variables are declared:
		//JProgressBar progressBar;
		
		//Where the GUI is constructed:
		//progressBar = new JProgressBar(0, task.getLengthOfTask());
		//progressBar.setValue(0);
		//progressBar.setStringPainted(true);
	}
	
	
	public static void main (String[] args) {
		new ProgressFrame();
	}
}
