package Items;

public class Platelegs2 extends Item {
	public Platelegs2 () {
		super ("pics/items/platelegs2.png");
		this.name = "Platelegs";
		this.internalName = "Platelegs 2";
		this.examineText = "A pair of platelegs made out of ... a strange red metal ?";
		this.option1 = "Equip";
		this.equipZone = 7;
		this.defBonus = 12;
		this.weight = 7;
		this.ID = 3003;
	}
}
