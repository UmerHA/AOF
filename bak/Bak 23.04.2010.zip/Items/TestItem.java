package Items;

public class TestItem extends Item {

	public TestItem(String picSrc) {
		super(picSrc);
	}

}
