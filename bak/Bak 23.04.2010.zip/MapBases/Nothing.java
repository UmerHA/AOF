package MapBases;

public class Nothing extends MapBase {

	public Nothing(int x, int y) {
		super(x, y,"pics/fields/Nothing.jpg");
	}
}
